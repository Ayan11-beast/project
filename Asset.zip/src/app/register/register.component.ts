import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Register } from '../models/register.model';
import { AssetManageService } from '../service/asset-manage.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 
  registerForm : Register = {

    assetId:'',
    issuedOn:'',
    issuedToEmployee:'',
    modelNo:0,
    make:'',
    assetType:''
  }

  constructor(private RService: AssetManageService) {}

  ngOnInit() : void {}

  handleSubmit(){
    this.RService.registerAsset(this.registerForm)
    .subscribe({
     next: (Register) => {
        console.log("Added Successfully");
      },
      error:(err)=>{
        console.log(err)
      }
    });
    alert("Asset with  id "+this.registerForm.assetId+" Registered ");

  }
}
