import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SupportComponent } from './support/support.component';
import { ResolveComponent } from './resolve/resolve.component';
import { TrackComponent } from './track/track.component';
import { HomeComponent } from './home/home.component';
import { SupportManageService } from './service/support-manage.service';
import { UpdateTicketStatusComponent } from './resolve/update-ticket-status/update-ticket-status.component';
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    NavbarComponent,
    SupportComponent,
    ResolveComponent,
    TrackComponent,
    HomeComponent,
    UpdateTicketStatusComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,

  ],
  providers: [SupportManageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
