import { Component, OnInit, ViewChild } from '@angular/core';
import { Resolve } from '../models/resolve.model';
import { ResolveService } from '../service/resolve.service';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, RouterEvent } from '@angular/router';
import { Support } from '../models/support.model';

@Component({
  selector: 'app-resolve',
  templateUrl: './resolve.component.html',
  styleUrls: ['./resolve.component.css']
})
export class ResolveComponent{

  supportTickets:Support[];
  resolve: Resolve;
  ticketIdVal:number;

  constructor(private RService: ResolveService,route:ActivatedRoute) {
    console.log("Resolve constrcutor");
    /*
    route.params.subscribe((ticketId)=>{
      console.log("Ticket id in resolve:"+JSON.stringify(ticketId));
     this.ticketIdVal=Number(ticketId);
      console.log("Ticket id:"+ticketId);
    })*//*
   this.ticketIdVal= route.snapshot.params["ticketId"];
    this.RService.getDetails(this.ticketIdVal).subscribe({
      next: (data:Resolve) =>{
        this.resolve=data;
        console.log("Resol:"+JSON.stringify(this.resolve));
      },
      error:(err)=>{

      }
    })
*/
RService.getSupportTickets().subscribe((data)=>{
this.supportTickets=data;
console.log("Support tickets:"+JSON.stringify(this.supportTickets));
});

   }

  handleSubmit(){
    /*this.RService.getDetails('ticketId').subscribe({
      next: (data:Resolve[]) =>{
        this.Resol=data;
      },
      error:(err)=>{

      }
    })*/
  }

}

