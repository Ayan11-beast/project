import { Component } from '@angular/core';
import { ResolveService } from 'src/app/service/resolve.service';
import { ActivatedRoute } from '@angular/router';
import { Validators, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-update-ticket-status',
  templateUrl: './update-ticket-status.component.html',
  styleUrls: ['./update-ticket-status.component.css']
})
export class UpdateTicketStatusComponent {
  ticketIdVal:number;
  constructor(private RService: ResolveService,route:ActivatedRoute) {
    console.log("Resolve constrcutor");
    
   this.ticketIdVal= route.snapshot.params["ticketId"];
   console.log("Ticket Id in update status:"+this.ticketIdVal);


   /*
    this.RService.getDetails(this.ticketIdVal).subscribe({
      next: (data:Resolve) =>{
        this.resolve=data;
        console.log("Resol:"+JSON.stringify(this.resolve));
      },
      error:(err)=>{

      }
    })
*/
}

formData: any;


ngOnInit(): void {

  this.formData = new FormGroup(
    {
      ticketId: new FormControl("", Validators.compose(
        [
          Validators.required,
        ]
      )),
      resolutionDate: new FormControl("", Validators.compose(
        [
          Validators.required
        ]
      )),
      resolutionDescription: new FormControl("", Validators.compose(
        [
          Validators.required,
        ]
      ))
    }
  );
  this.formData.get("ticketId").value=this.ticketIdVal;
}
onSubmit(data){
  let ticketIdFromResponse;
  console.log(JSON.stringify(data));
  this.RService.resolveTicket(this.ticketIdVal,data).subscribe((response)=>{
    console.log("Ticket id:"+response.ticketId);    
  })
  alert("Ticket is "+data.ticketId+" Resolved ");

}
}