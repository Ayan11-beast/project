import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Resolve } from '../models/resolve.model';
import { Observable } from 'rxjs';
import { Support } from '../models/support.model';

@Injectable({
  providedIn: 'root'
})
export class ResolveService {

  constructor(private http:HttpClient) { }

  getDetails(ticketid:number): Observable<Resolve>{
    console.log("In resolve service:"+ticketid);
    //console.log("Ticket id in service:"+JSON.stringify(ticketid));
    return this.http.get<Resolve>("http://localhost:8090/api" + '/supportrequest/'+ticketid);
  }
  getSupportTickets(): Observable<Support[]>{
    //console.log("Ticket id in service:"+JSON.stringify(ticketid));
    return this.http.get<Support[]>("http://localhost:8090/api/supporttickets");
  }

  resolveTicket(ticketId:number,resolution:Resolve): Observable<Resolve>{
    //console.log("Ticket id in service:"+JSON.stringify(ticketid));
    return this.http.put<Resolve>("http://localhost:8090/api/supportrequests/"+ticketId+"/resolve",resolution);
  }
}
