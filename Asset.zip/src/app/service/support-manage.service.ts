import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environment/environment';
import { Track } from '../models/track.model';
import { Register } from '../models/register.model';
import { Support } from '../models/support.model';

@Injectable({
  providedIn: 'root'
})
export class SupportManageService {

  baseApiUrl: string = environment.baseApiUrl;

  constructor(private http: HttpClient) { }


  registerSupport(support: Support): Observable<Support> {
    console.log("Register support:"+JSON.stringify(support));
    support.ticketStatus="NEW";
    return this.http.post<Support>("http://localhost:8090/api" + '/supportrequests/new',
    support);
 }

 

}