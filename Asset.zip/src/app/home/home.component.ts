import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent {
  // bgImage: string = "https://www.vitechinc.com/wp-content/uploads/2022/03/partner-logos_cognizant-new.png"
}
