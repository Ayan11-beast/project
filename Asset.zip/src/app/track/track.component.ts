import { Component, OnInit } from '@angular/core';
import { Track } from '../models/track.model';
import { AssetManageService } from '../service/asset-manage.service';

@Component({
  selector: 'app-track',
  templateUrl: './track.component.html',
  styleUrls: ['./track.component.css']
})
export class TrackComponent implements OnInit {

  trackForm : Track = {

    tickedtId:0,
    issuedby:'',
    issuedon:'',
    assetId:'',
    assignedTo:'',
    expectedResol:'',
    ticketstat:''
  };

  tickets: Track[] = [];

  constructor(private trackservice: AssetManageService) { }

  ngOnInit(): void {}

  onsubmit(){
    this.trackservice.getTicketdetails(this.trackForm.tickedtId)
    .subscribe({
      next:(response) => {
        console.log(response);
      }
    });
  
  }

}
