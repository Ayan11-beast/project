import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SupportComponent } from './support/support.component';
import { RegisterComponent } from './register/register.component';
import { ResolveComponent } from './resolve/resolve.component';
import { TrackComponent } from './track/track.component';
import { HomeComponent } from './home/home.component';
import { UpdateTicketStatusComponent } from './resolve/update-ticket-status/update-ticket-status.component';

const routes: Routes = [
  
  {
    path:'',
    component: HomeComponent
  },

  {
    path:'register',
    component: RegisterComponent
  },
  
  {
    path:'support',
    component:SupportComponent
  },

  /*
  {
    path:'resolve/:ticketId',
    component:ResolveComponent
  },
*/
{
  path:'resolve',
  component: ResolveComponent
},
  {
    path:'track',
    component:TrackComponent
  },
  {
    path:'updateTicketStatus/:ticketId',
    component: UpdateTicketStatusComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
