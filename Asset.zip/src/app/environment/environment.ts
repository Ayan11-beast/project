export const environment = {
    production: false,
    baseApiUrl: 'http://localhost:8090'
};