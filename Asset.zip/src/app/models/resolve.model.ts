export class Resolve{

    id:number;
    ticketId:number;
    resolutionDate:string;
    resolutionDescription:string;
}