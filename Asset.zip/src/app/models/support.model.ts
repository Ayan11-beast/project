export interface Support{

    ticketId:string;
    ticketRaisedOn:string;
    ticketRaisedByEmployee:string;
    assetId:string;
    assignedToEmployee:string;
    expectedResolution:string;
    ticketStatus:string;
}