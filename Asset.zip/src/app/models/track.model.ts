export class Track{

    public tickedtId:number;
    public issuedby:string;
    public issuedon:string;
    public assetId:string;
    public assignedTo:string;
    public expectedResol:string;
    public ticketstat:string;
}