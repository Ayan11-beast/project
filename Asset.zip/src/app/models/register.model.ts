export class Register{

   assetId:string;
   issuedOn:string;
   issuedToEmployee:string;
   modelNo:number;
   make:string;
   assetType:string;

}