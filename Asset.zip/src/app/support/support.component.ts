import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Support } from '../models/support.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SupportManageService } from '../service/support-manage.service';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent {
  constructor(private router: Router, private supportManageService:SupportManageService) { }
  formData: any;


  ngOnInit(): void {

    this.formData = new FormGroup(
      {
        ticketId: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),
        ticketRaisedOn: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),/*
        aId: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),*/
        assignedToEmployee: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),
        assetId: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),
        ticketRaisedByEmployee: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        )),/*
        expresol: new FormControl("", Validators.compose(
          [
            Validators.required
          ]
        )),*/

        expectedResolution: new FormControl("", Validators.compose(
          [
            Validators.required
          ]
        )),
        ticketStatus: new FormControl("", Validators.compose(
          [
            Validators.required,
          ]
        ))
      }
    );
  }


/*
  onSubmit(data) {
    console.log("button clicked");
    console.log(data);
    this.router.navigate(['/resolve']);
    // console.log(this.SupportForm); 
  }*/

  onSubmit(data){
    console.log("submit of support:"+JSON.stringify(data));
    this.supportManageService.registerSupport(data)
    .subscribe({
     next: (Support) => {
        console.log("Added Successfully");
      },
      error:(err)=>{
        console.log(err)
      }
    });
    alert("Support Ticket with  id "+data.ticketId+" Raised ");

  }

  /*
    SupportForm : Support = {
  
      raisedon:'',
      aId:'',
      raisedby:'',
      assignedTo:'',
      expresol:'',
      stat:'',
  
    };*/



  handlesubmit() {
    //    console.log(this.SupportForm);
  }
}
