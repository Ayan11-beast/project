package com.cognizant.controller;

import com.cognizant.EmiExtensionsManagementApplication;
import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.ExtensionsRequestResponses;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.IdNotValidException;
import com.cognizant.service.impl.ExtensionRequestsServiceImpl;
import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = EmiExtensionsManagementApplication.class)
class ExtensionRequestsControllerTest {
    @InjectMocks
    private ExtensionRequestsController extensionRequestsController;

    @Mock
    private ExtensionRequestsServiceImpl extensionRequestsService;

    private MockMvc mockMvc;

    @Autowired
    private LocalValidatorFactoryBean validator;

    private MockRestServiceServer mockServer;

    private RestTemplate template;

    /**
     * This method run every time before a test method run.
     */
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(extensionRequestsController).build();
        template = new RestTemplate();
        mockServer = MockRestServiceServer.createServer(template);

        String reason = "qwertyuiopwertyuipqwertyopqwertyuiopqwertyuiopqwt";
        ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO(1, "Reason 1");
        ExtensionRequests extensionRequests = new ExtensionRequests(
                111, 112, 113, 114, extensionReasons, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New
        );
        ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
        );
        ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses(
                220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
        );
        ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO(
                220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
        );
    }

    /**
     * This test validate that method to raise new request for EMI extension is working properly if required information provided.
     */
    @Test
    void raiseNewRequest_Positive() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals("Data inserted successfully.", responseEntity.getBody());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is working properly if required information is not provided.
     */
    @Test
    void raiseNewRequest_Negative() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals("Error occurred during inserting data.", responseEntity.getBody());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is throwing and catching exception properly.
     */
    @Test
    void raiseNewRequest_NullException() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenThrow(new NullPointerException("Extension Request can not be null."));

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals("Error occurred during inserting data.", responseEntity.getBody());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is throwing and catching exception properly.
     */
    @Test
    void raiseNewRequest_IdNotFoundException() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenThrow(new IdNotValidException("Unable to insert as id is not valid"));

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals("Error occurred during inserting data.", responseEntity.getBody());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is giving OK status if provided with correct information.
     */
    @Test
    void raiseNewRequest_PositiveStatusCode() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is giving BAD_REQUEST status if provided with correct information.
     */
    @Test
    void raiseNewRequest_NegativeStatusCode() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }


    /**
     * This test validate that method to raise new request for EMI extension is giving BAD_REQUEST status if provided with correct information.
     */
    @Test
    void raiseNewRequest_ExceptionStatusCode() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenThrow(new IdNotValidException("Unable to insert as id is not valid"));

            ResponseEntity<?> responseEntity = extensionRequestsController.raiseNewRequest(extensionRequestsDTO);
            assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is working if provided with correct request id.
     */
    @Test
    void raiseNewRequest_ValidRequestId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "requestId")
                    .forEach((constraintViolation) -> assertNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is not working if provided with incorrect request id.
     */
    @Test
    void raiseNewRequest_InvalidRequestId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    0, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "requestId")
                    .forEach((constraintViolation) -> assertNotNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is working if provided with correct emi id.
     */
    @Test
    void raiseNewRequest_ValidEmiId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "emiId")
                    .stream()
                    .forEach((constraintViolation) -> assertNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is not working if provided with incorrect emi id.
     */
    @Test
    void raiseNewRequest_InvalidEmiId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 0, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "emiId")
                    .forEach((constraintViolation) -> assertNotNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is working if provided with correct customer id.
     */
    @Test
    void raiseNewRequest_ValidCustomerId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "customerId")
                    .stream()
                    .forEach((constraintViolation) -> assertNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is not working if provided with incorrect customer id.
     */
    @Test
    void raiseNewRequest_InvalidCustomerId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 0, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "customerId")
                    .forEach((constraintViolation) -> assertNotNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is working if provided with correct loan plan id.
     */
    @Test
    void raiseNewRequest_ValidLoanPlanId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "customerId")
                    .stream()
                    .forEach((constraintViolation) -> assertNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to raise new request for EMI extension is not working if provided with incorrect loan plan id.
     */
    @Test
    void raiseNewRequest_InvalidLoanPlanId() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 0, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);

            validator.validateProperty(extensionRequestsDTO, "loanPlanId")
                    .forEach((constraintViolation) -> assertNotNull(constraintViolation));
        } catch (IdNotValidException | NullPointerException e) {
            fail(e.getMessage());
        }
    }

//    @Test
//    void raiseNewRequest_ValidURI() {
//        try {
//            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
//            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
//                    111, 1110, 11100, 111000, "no other reason", LocalDate.now(), LocalDate.now().plusWeeks(1), RequestStatus.New, extensionReasons
//            );
//            when(extensionRequestsService.insertExtensionRequests(Mockito.any())).thenReturn(extensionRequestsDTO);
//            ObjectMapper mapper = new ObjectMapper();
//            mapper.registerModule(new JavaTimeModule());
//            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
//            mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
//            ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
//            String json = ow.writeValueAsString(extensionRequestsDTO);
//
//            mockMvc.perform(post("http://localhost:8085/api/emiextensions/newrequest")
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(json)
//                            .accept(MediaType.TEXT_PLAIN))
//                    .andExpect(status().isOk())
//                    .andReturn();
//        } catch (Exception e) {
//            fail(e.getMessage());
//        }
//    }

    /**
     * This test validate that method to fetch all EMI extension requests is working if provided with correct information.
     */
    @Test
    void getNewExtensionRequests_Positive() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            extensionRequestsDTOList.add(extensionRequestsDTO);
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequests();
            List<ExtensionRequestsDTO> newExtensionRequestsDTOList = (List<ExtensionRequestsDTO>) responseEntity.getBody();
            assertEquals(1, newExtensionRequestsDTOList.size());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is working if provided with incorrect information.
     */
    @Test
    void getNewExtensionRequests_Negative() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequests();
            assertEquals("No data found.", responseEntity.getBody());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is giving OK status if provided with correct information.
     */
    @Test
    void getNewExtensionRequests_PositiveStatusCode() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            extensionRequestsDTOList.add(extensionRequestsDTO);
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequests();
            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is giving BAD_REQUEST status if provided with incorrect information.
     */
    @Test
    void getNewExtensionRequests_NegativeStatusCode() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequests();
            assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is working if provided with correct URI.
     */
    @Test
    void getNewExtensionRequests_ValidURI() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            extensionRequestsDTOList.add(extensionRequestsDTO);
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            mockMvc.perform(get("http://localhost:8085/api/emiextensions"))
                    .andExpect(status().isOk()).andReturn();

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is not working if provided with incorrect URI.
     */
    @Test
    void getNewExtensionRequests_InvalidURI() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            extensionRequestsDTOList.add(extensionRequestsDTO);
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            mockMvc.perform(get("http://localhost:8085/api/emiextension"))
                    .andExpect(status().isNotFound()).andReturn();
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch all EMI extension requests is returning correct JSON if provided with correct information.
     */
    @Test
    void getNewExtensionRequests_ValidJSON() {
        try {
            List<ExtensionRequestsDTO> extensionRequestsDTOList = new ArrayList<>();
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            extensionRequestsDTOList.add(extensionRequestsDTO);
            when(extensionRequestsService.fetchAllExtensionRequests()).thenReturn(extensionRequestsDTOList);

            MvcResult mvcResult = mockMvc.perform(get("http://localhost:8085/api/emiextensions"))
                    .andExpect(status().isOk()).andReturn();
            String actual = mvcResult.getResponse().getContentAsString();
            int id = JsonPath.parse(actual).read("$[0].requestId");
            assertEquals(111, id);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is working if provided with correct information.
     */
    @Test
    void getNewExtensionRequestsById_Positive() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            ExtensionRequestsDTO newExtensionRequestsDTO = (ExtensionRequestsDTO) responseEntity.getBody();
            assertEquals(111, newExtensionRequestsDTO.getRequestId());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is working if provided with incorrect information.
     */
    @Test
    void getNewExtensionRequestsById_Negative() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            assertEquals("Error occurred while fetching data.", responseEntity.getBody());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is throwing and exception properly.
     */
    @Test
    void getNewExtensionRequestsById_Exception() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenThrow(new IdNotFoundException("No data found for the id."));

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            assertEquals("No data found for the given id.", responseEntity.getBody());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is giving OK status if provided with correct information.
     */
    @Test
    void getNewExtensionRequestsById_PositiveStatusCode() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is giving BAD_REQUEST status if provided with incorrect information.
     */
    @Test
    void getNewExtensionRequestsById_NegativeStatusCode() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is giving BAD_REQUEST status if throwing exception.
     */
    @Test
    void getNewExtensionRequestsById_ExceptionStatusCode() {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenThrow(new IdNotFoundException("No data found for the id."));

            ResponseEntity<?> responseEntity = extensionRequestsController.getNewExtensionRequestsById(111);
            assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is working if provided with correct URI.
     */
    @Test
    void getNewExtensionRequestsById_ValidURI() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            mockMvc.perform(get("http://localhost:8085/api/emiextensions/{requestId}", 111))
                    .andExpect(status().isOk()).andReturn();

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is not working if provided with incorrect URI.
     */
    @Test
    void getNewExtensionRequestsById_InvalidURI() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            mockMvc.perform(get("http://localhost:8085/api/emiextension/{requestId}", 100))
                    .andExpect(status().isNotFound()).andReturn();
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * This test validate that method to fetch an EMI extension request is returning correct JSON if provided with correct information.
     */
    @Test
    void getNewExtensionRequestsById_ValidJSON() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO(
                    111, 112, 113, 114, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New, extensionReasons
            );
            when(extensionRequestsService.fetchExtensionRequestsById(Mockito.anyInt())).thenReturn(extensionRequestsDTO);

            MvcResult mvcResult = mockMvc.perform(get("http://localhost:8085/api/emiextensions/{requestId}", 100))
                    .andExpect(status().isOk()).andReturn();
            String actual = mvcResult.getResponse().getContentAsString();
            int id = JsonPath.parse(actual).read("requestId");
            assertEquals(111, id);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

}