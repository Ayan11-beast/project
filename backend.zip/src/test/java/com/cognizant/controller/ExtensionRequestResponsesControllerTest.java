package com.cognizant.controller;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.service.impl.ExtensionsRequestResponsesServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ExtensionRequestResponsesControllerTest {

    @InjectMocks
    private ExtensionRequestResponsesController extensionRequestResponsesController;

    @Mock
    private ExtensionsRequestResponsesServiceImpl extensionsRequestResponsesService;

    private MockMvc mockMvc;

    private MockRestServiceServer mockServer;

    private RestTemplate template;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(extensionRequestResponsesController).build();
        template = new RestTemplate();
        mockServer = MockRestServiceServer.createServer(template);
    }

    @Test
    void updateExtensionRequestsApproval_Positive() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequests extensionRequests = new ExtensionRequests(
                    111, 112, 113, 114, extensionReasons, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New
            );
            String reason = "qwertyuiopwertyuipqwertyopqwertyuiopqwertyuiopqwt";
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO(
                    220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
            );

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenReturn(extensionsRequestResponsesDTO);

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals("Updated successfully.", response.getBody());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_Negative() {
        try {
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenReturn(extensionsRequestResponsesDTO);

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals("Error occurred while updating.", response.getBody());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_IdNotFoundException() {
        try {
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenThrow(new IdNotFoundException("No data found to update on this id."));

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(1000, extensionsRequestResponsesDTO);
            assertEquals("No data found for the given id.", response.getBody());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_PositiveStatusCode() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequests extensionRequests = new ExtensionRequests(
                    111, 112, 113, 114, extensionReasons, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New
            );
            String reason = "qwertyuiopwertyuipqwertyopqwertyuiopqwertyuiopqwt";
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO(
                    220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
            );

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenReturn(extensionsRequestResponsesDTO);

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals(HttpStatus.OK, response.getStatusCode());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_NegativeStatusCode() {
        try {
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenReturn(extensionsRequestResponsesDTO);

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_ExceptionStatusCode() {
        try {
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();

            when(extensionsRequestResponsesService.extensionsRequestsApproval(anyInt(), any())).thenThrow(new IdNotFoundException("No data found to update on this id."));

            ResponseEntity<?> response = extensionRequestResponsesController.updateExtensionRequestsApproval(1000, extensionsRequestResponsesDTO);
            assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_ValidURI() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequests extensionRequests = new ExtensionRequests(
                    100, 112, 113, 114, extensionReasons, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New
            );
            String reason = "123456789012345678901234567890123456789012345678901234567890";
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO(
                    220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
            );

            when(extensionsRequestResponsesService.extensionsRequestsApproval(100, extensionsRequestResponsesDTO)).thenReturn(extensionsRequestResponsesDTO);
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
            ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
            String json = ow.writeValueAsString(extensionsRequestResponsesDTO);

            mockMvc.perform(put("http://localhost:8085/api/emiextension" +
                            "s/{requestId}", 100)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andReturn();
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    void updateExtensionRequestsApproval_InvalidURI() {
        try {
            ExtensionReasons extensionReasons = new ExtensionReasons(1, "Reason 1");
            ExtensionRequests extensionRequests = new ExtensionRequests(
                    100, 112, 113, 114, extensionReasons, "no other reason", LocalDate.now(), LocalDate.now(), RequestStatus.New
            );
            String reason = "123456789012345678901234567890123456789012345678901234567890";
            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO(
                    220, reason, false, LocalDate.now().plusWeeks(1), extensionRequests
            );

            when(extensionsRequestResponsesService.extensionsRequestsApproval(100, extensionsRequestResponsesDTO)).thenReturn(extensionsRequestResponsesDTO);
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
            ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
            String json = ow.writeValueAsString(extensionsRequestResponsesDTO);

            mockMvc.perform(put("http://localhost:8085/api/emiextension" +
                            "/{requestId}", 100)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(json)
                            .accept(MediaType.APPLICATION_JSON))
                    .andExpect(status().isNotFound())
                    .andReturn();
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

}