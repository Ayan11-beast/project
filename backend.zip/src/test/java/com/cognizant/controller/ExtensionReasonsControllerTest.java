package com.cognizant.controller;

import com.cognizant.EmiExtensionsManagementApplication;
import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.service.impl.ExtensionReasonsServiceImpl;
import com.jayway.jsonpath.JsonPath;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = EmiExtensionsManagementApplication.class)
class ExtensionReasonsControllerTest {

    @InjectMocks
    private ExtensionReasonsController extensionReasonsController;

    @Mock
    private ExtensionReasonsServiceImpl extensionReasonsService;

    private MockMvc mockMvc;

    @Autowired
    private LocalValidatorFactoryBean validator;

    private MockRestServiceServer mockServer;

    private RestTemplate template;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(extensionReasonsController).build();
        template = new RestTemplate();
        mockServer = MockRestServiceServer.createServer(template);
    }

    @Test
    void getExtensionReasons_Positive() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);
        extensionReasonsDTOList.add(extensionReasonsDTO);
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);

        ResponseEntity<?> response = extensionReasonsController.getExtensionReasons();
        List<ExtensionReasonsDTO> extensionReasonsDTOs = (List<ExtensionReasonsDTO>) response.getBody();
        assertEquals(1, extensionReasonsDTOs.size());
    }

    @Test
    void getExtensionReasons_Negative() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);

        ResponseEntity<?> response = extensionReasonsController.getExtensionReasons();
        assertEquals("No record found.",response.getBody());
    }

    @Test
    void getExtensionReasons_PositiveStatusCode() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);
        extensionReasonsDTOList.add(extensionReasonsDTO);
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);

        ResponseEntity<?> response = extensionReasonsController.getExtensionReasons();
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void getExtensionReasons_NegativeStatusCode() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);

        ResponseEntity<?> response = extensionReasonsController.getExtensionReasons();
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void persistExtensionReason_ForValidReason() {
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);

        validator.validateProperty(ExtensionReasonsDTO.class, "reason")
                .forEach(Assertions::assertNull);
    }

    @Test
    void persistExtensionReason_ForInvalidReason() {
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("");
        extensionReasonsDTO.setId(100);

        validator.validateProperty(extensionReasonsDTO, "reason")
                .forEach((constraintViolation) -> assertEquals("You have reached Maximum Extension Requests for this Loan.", constraintViolation.getMessage()));
    }

    @Test
    void persistExtensionReason_ForInvalidReasonValidMessage() {
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("");
        extensionReasonsDTO.setId(100);

        validator.validateProperty(extensionReasonsDTO, "reason")
                .forEach(Assertions::assertNotNull);
    }


    @Test
    void getExtensionsReasons_ValidURI() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);
        extensionReasonsDTOList.add(extensionReasonsDTO);
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);
        try {
            MvcResult mvcResult = mockMvc.perform(get("http://localhost:8085/api/emiextensions/reasons"))
                    .andExpect(status().isOk()).andReturn();
            int actual = mvcResult.getResponse().getStatus();
            assertEquals(200, actual);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    void getExtensionsReasons_InvalidURI() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);
        extensionReasonsDTOList.add(extensionReasonsDTO);
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);
        try {
            MvcResult mvcResult = mockMvc.perform(get("http://localhost:8085/api/emiextensions/reason"))
                    .andExpect(status().isNotFound()).andReturn();
            int actual = mvcResult.getResponse().getStatus();
            assertEquals(404, actual);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    void getExtensionsReasons_PositiveJSON() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
        extensionReasonsDTO.setReason("Reasons");
        extensionReasonsDTO.setId(100);
        extensionReasonsDTOList.add(extensionReasonsDTO);
        when(extensionReasonsService.fetchAllExtensionReasons()).thenReturn(extensionReasonsDTOList);
        try {
            MvcResult mvcResult = mockMvc.perform(get("http://localhost:8085/api/emiextensions/reasons"))
                    .andExpect(status().isOk()).andReturn();
            String actual = mvcResult.getResponse().getContentAsString();
            int id = JsonPath.parse(actual).read("$[0].id");
            assertEquals(100, id);
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
