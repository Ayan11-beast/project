package com.cognizant.repositories;

import com.cognizant.EmiExtensionsManagementApplication;
import com.cognizant.entities.ExtensionsRequestResponses;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ContextConfiguration(classes = EmiExtensionsManagementApplication.class)
class ExtensionsRequestResponsesRepositoryTest {

    @Autowired
    private ExtensionsRequestResponsesRepository extensionsRequestResponsesRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllNegative() {
        List<ExtensionsRequestResponses> extensionsRequestResponsesList = (List<ExtensionsRequestResponses>) extensionsRequestResponsesRepository.findAll();
        assertEquals(5, extensionsRequestResponsesList.size());
    }

    @Test
    void testFindAllPositive() {
        ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
        extensionsRequestResponses.setId(100);
        extensionsRequestResponses.setResponse("No response");
        extensionsRequestResponses.setResponseDate(LocalDate.now());
        extensionsRequestResponses.setExtensionGranted(false);
        entityManager.persist(extensionsRequestResponses);
        Iterable<ExtensionsRequestResponses> extensionsRequestResponsesOptional = extensionsRequestResponsesRepository.findAll();
        assertTrue(extensionsRequestResponsesOptional.iterator().hasNext());
    }

    @Test
    void testFindByIdNegative() {
        Optional<ExtensionsRequestResponses> extensionsRequestResponsesOptional = extensionsRequestResponsesRepository.findById(100);
        assertFalse(extensionsRequestResponsesOptional.isPresent());
    }

    @Test
    void testSavePositive() {
        ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
        extensionsRequestResponses.setId(100);
        extensionsRequestResponses.setResponse("No response");
        extensionsRequestResponses.setResponseDate(LocalDate.now());
        extensionsRequestResponses.setExtensionGranted(false);
        extensionsRequestResponsesRepository.save(extensionsRequestResponses);
        Optional<ExtensionsRequestResponses> extensionRequestsOptional = extensionsRequestResponsesRepository.findById(100);
        assertTrue(extensionRequestsOptional.isPresent());
    }

    @Test
    void testDeletePositive() {
        ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
        extensionsRequestResponses.setId(100);
        extensionsRequestResponses.setResponse("No response");
        extensionsRequestResponses.setResponseDate(LocalDate.now());
        extensionsRequestResponses.setExtensionGranted(false);
        extensionsRequestResponsesRepository.delete(extensionsRequestResponses);
        Optional<ExtensionsRequestResponses> extensionRequestsOptional = extensionsRequestResponsesRepository.findById(100);
        assertFalse(extensionRequestsOptional.isPresent());

    }
}