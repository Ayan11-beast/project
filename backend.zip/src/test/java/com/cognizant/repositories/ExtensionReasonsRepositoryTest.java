package com.cognizant.repositories;

import com.cognizant.EmiExtensionsManagementApplication;
import com.cognizant.entities.ExtensionReasons;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ContextConfiguration(classes = EmiExtensionsManagementApplication.class)
class ExtensionReasonsRepositoryTest {

    @Autowired
    private ExtensionReasonsRepository extensionReasonsRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllPositive() {
        ExtensionReasons extensionReasons = new ExtensionReasons();
        extensionReasons.setId(100);
        extensionReasons.setReason("NON");
        entityManager.persist(extensionReasons);
        Iterable<ExtensionReasons> iterable = extensionReasonsRepository.findAll();
        assertTrue(iterable.iterator().hasNext());
    }

    @Test
    void testFindAllNegative() {
        List<ExtensionReasons> extensionReasonsList = (List<ExtensionReasons>) extensionReasonsRepository.findAll();
        assertEquals(5, extensionReasonsList.size());
    }


    @Test
    void testFindByIdPositive() {
        ExtensionReasons extensionReasons = new ExtensionReasons();
        extensionReasons.setId(100);
        extensionReasons.setReason("NON");
        entityManager.persist(extensionReasons);
        Optional<ExtensionReasons> extensionReasonsOptional = extensionReasonsRepository.findById(100);
        assertTrue(extensionReasonsOptional.isPresent());
    }

    @Test
    void testFindByIdNegative() {
        Optional<ExtensionReasons> extensionReasonsOptional = extensionReasonsRepository.findById(100);
        assertFalse(extensionReasonsOptional.isPresent());
    }

    @Test
    void testSavePositive() {
        ExtensionReasons extensionReasons = new ExtensionReasons();
        extensionReasons.setId(100);
        extensionReasons.setReason("NON");
        extensionReasonsRepository.save(extensionReasons);
        Optional<ExtensionReasons> extensionReasonsOptional = extensionReasonsRepository.findById(100);
        assertTrue(extensionReasonsOptional.isPresent());
    }

    @Test
    void testDeletePositive() {
        ExtensionReasons extensionReasons = new ExtensionReasons();
        extensionReasons.setId(100);
        extensionReasons.setReason("NON");
        entityManager.persist(extensionReasons);
        extensionReasonsRepository.delete(extensionReasons);
        Optional<ExtensionReasons> extensionReasonsOptional = extensionReasonsRepository.findById(100);
        assertFalse(extensionReasonsOptional.isPresent());
    }

}