package com.cognizant.repositories;

import com.cognizant.EmiExtensionsManagementApplication;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.RequestStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ContextConfiguration(classes = EmiExtensionsManagementApplication.class)
class ExtensionRequestsRepositoryTest {

    @Autowired
    private ExtensionRequestsRepository extensionRequestsRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllPositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(110);
        extensionRequests.setEmiId(1010);
        extensionRequests.setCustomerId(10010);
        extensionRequests.setLoanPlanId(100010);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        entityManager.persist(extensionRequests);
        Iterable<ExtensionRequests> iterable = extensionRequestsRepository.findAll();
        assertTrue(iterable.iterator().hasNext());
    }

    @Test
    void testFindAllNegative() {
        List<ExtensionRequests> extensionRequestsList = (List<ExtensionRequests>) extensionRequestsRepository.findAll();
        assertEquals(5, extensionRequestsList.size());
    }

    @Test
    void testFindAllByCustomerIdPositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(110);
        extensionRequests.setEmiId(1010);
        extensionRequests.setCustomerId(10010);
        extensionRequests.setLoanPlanId(100010);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        entityManager.persist(extensionRequests);
        Iterable<ExtensionRequests> iterable = extensionRequestsRepository.findAllByCustomerId(10010);
        assertTrue(iterable.iterator().hasNext());
    }

    @Test
    void testFindAllByCustomerIdNegative() {
        Iterable<ExtensionRequests> iterable = extensionRequestsRepository.findAllByCustomerId(102);
        assertFalse(iterable.iterator().hasNext());
    }

    @Test
    void testFindAllByLoanPlanIdPositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(110);
        extensionRequests.setEmiId(1010);
        extensionRequests.setCustomerId(10010);
        extensionRequests.setLoanPlanId(100010);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        entityManager.persist(extensionRequests);
        Iterable<ExtensionRequests> iterable = extensionRequestsRepository.findAllByLoanPlanId(100010);
        assertTrue(iterable.iterator().hasNext());
    }

    @Test
    void testFindAllByLoanPlanIdNegative() {
        Iterable<ExtensionRequests> iterable = extensionRequestsRepository.findAllByLoanPlanId(103);
        assertFalse(iterable.iterator().hasNext());
    }

    @Test
    void testFindByIdPositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(110);
        extensionRequests.setEmiId(1010);
        extensionRequests.setCustomerId(10010);
        extensionRequests.setLoanPlanId(100010);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        entityManager.persist(extensionRequests);
        Optional<ExtensionRequests> extensionRequestsOptional = extensionRequestsRepository.findById(100);
        assertTrue(extensionRequestsOptional.isPresent());
    }

    @Test
    void testFindByIdNegative() {
        Optional<ExtensionRequests> extensionRequestsOptional = extensionRequestsRepository.findById(1000);
        assertFalse(extensionRequestsOptional.isPresent());
    }

    @Test
    void testSavePositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(100);
        extensionRequests.setEmiId(101);
        extensionRequests.setCustomerId(102);
        extensionRequests.setLoanPlanId(103);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        extensionRequestsRepository.save(extensionRequests);
        Optional<ExtensionRequests> extensionRequestsOptional = extensionRequestsRepository.findById(100);
        assertTrue(extensionRequestsOptional.isPresent());
    }

    @Test
    void testDeletePositive() {
        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(100);
        extensionRequests.setEmiId(101);
        extensionRequests.setCustomerId(102);
        extensionRequests.setLoanPlanId(103);
        extensionRequests.setOtherReason("non");
        extensionRequests.setRequestRaisedOn(LocalDate.now());
        extensionRequests.setEtaPaymentDate(LocalDate.now().plusWeeks(3));
        extensionRequests.setRequestStatus(RequestStatus.New);
        entityManager.persist(extensionRequests);
        extensionRequestsRepository.delete(extensionRequests);
        Optional<ExtensionRequests> extensionRequestsOptional = extensionRequestsRepository.findById(100);
        assertTrue(!extensionRequestsOptional.isPresent());
    }

}