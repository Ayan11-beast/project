package com.cognizant.service;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.ExtensionsRequestResponses;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.IdNotValidException;
import com.cognizant.repositories.ExtensionRequestsRepository;
import com.cognizant.service.impl.ExtensionRequestsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Fail.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ExtensionRequestsServiceImplTest {
    @Mock
    public ExtensionRequestsRepository extensionRequestsRepository;

    @InjectMocks
    public ExtensionRequestsServiceImpl extensionRequestsServiceImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void fetchExtensionRequestsById_Positive() {
        Optional<ExtensionRequests> mockOptional = mock(Optional.class);
        when(extensionRequestsRepository.findById(Mockito.any())).thenReturn(mockOptional);
        ExtensionRequests mockExtensionRequests = mock(ExtensionRequests.class);
        when(mockOptional.isPresent()).thenReturn(true);
        when(mockOptional.get()).thenReturn(mockExtensionRequests);
        when(mockExtensionRequests.getRequestId()).thenReturn(100);
        when(mockExtensionRequests.getEmiId()).thenReturn(101);
        when(mockExtensionRequests.getCustomerId()).thenReturn(102);
        when(mockExtensionRequests.getLoanPlanId()).thenReturn(103);
        when(mockExtensionRequests.getOtherReason()).thenReturn("non");
        when(mockExtensionRequests.getRequestRaisedOn()).thenReturn(LocalDate.now());
        when(mockExtensionRequests.getEtaPaymentDate()).thenReturn(LocalDate.now().plusWeeks(3));
        when(mockExtensionRequests.getRequestStatus()).thenReturn(RequestStatus.New);

        ExtensionRequestsDTO extensionRequestsDTO = null;
        try {
            extensionRequestsDTO = extensionRequestsServiceImpl.fetchExtensionRequestsById(100);
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
        assertEquals(100, extensionRequestsDTO.getRequestId());
    }

    @Test
    void fetchExtensionRequestsById_NegativeWithException() {
        Optional<ExtensionRequests> mockOptional = mock(Optional.class);
        when(extensionRequestsRepository.findById(Mockito.any())).thenReturn(mockOptional);
        when(mockOptional.isPresent()).thenReturn(false);

        assertThrows(IdNotFoundException.class, () -> extensionRequestsServiceImpl.fetchExtensionRequestsById(100));
    }

    @Test
    void fetchAllExtensionRequests_Positive() {
        Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
        when(extensionRequestsRepository.findAll()).thenReturn(mockExtensionRequestsIterable);
        Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
        when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
        when(mockExtensionRequestsIterator.hasNext()).thenReturn(true).thenReturn(false);
        ExtensionRequests mockExtensionRequests = mock(ExtensionRequests.class);
        when(mockExtensionRequestsIterator.next()).thenReturn(mockExtensionRequests);
        when(mockExtensionRequests.getRequestId()).thenReturn(100);
        when(mockExtensionRequests.getEmiId()).thenReturn(101);
        when(mockExtensionRequests.getCustomerId()).thenReturn(102);
        when(mockExtensionRequests.getLoanPlanId()).thenReturn(103);
        when(mockExtensionRequests.getOtherReason()).thenReturn("non");
        when(mockExtensionRequests.getRequestRaisedOn()).thenReturn(LocalDate.now());
        when(mockExtensionRequests.getEtaPaymentDate()).thenReturn(LocalDate.now().plusWeeks(3));
        when(mockExtensionRequests.getRequestStatus()).thenReturn(RequestStatus.New);

        List<ExtensionRequestsDTO> extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequests();
        assertEquals(1, extensionRequestsDTO.size());
    }

    @Test
    void fetchAllExtensionRequests_Negative() {
        Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
        when(extensionRequestsRepository.findAll()).thenReturn(mockExtensionRequestsIterable);
        Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
        when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
        when(mockExtensionRequestsIterator.hasNext()).thenReturn(false);

        List<ExtensionRequestsDTO> extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequests();
        assertEquals(0, extensionRequestsDTO.size());
    }

    @Test
    void fetchAllExtensionRequestsByLoanPlanId_Positive() {
        try {
            Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
            when(extensionRequestsRepository.findAllByLoanPlanId(anyInt())).thenReturn(mockExtensionRequestsIterable);
            Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
            when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
            when(mockExtensionRequestsIterator.hasNext()).thenReturn(true).thenReturn(false);
            ExtensionRequests mockExtensionRequests = mock(ExtensionRequests.class);
            when(mockExtensionRequestsIterator.next()).thenReturn(mockExtensionRequests);
            RequestStatus mockRequestsStatus = mock(RequestStatus.class);
            when(mockExtensionRequests.getRequestId()).thenReturn(100);
            when(mockExtensionRequests.getEmiId()).thenReturn(101);
            when(mockExtensionRequests.getCustomerId()).thenReturn(102);
            when(mockExtensionRequests.getLoanPlanId()).thenReturn(103);
            when(mockExtensionRequests.getOtherReason()).thenReturn("non");
            when(mockExtensionRequests.getRequestRaisedOn()).thenReturn(LocalDate.now());
            when(mockExtensionRequests.getEtaPaymentDate()).thenReturn(LocalDate.now().plusWeeks(3));
            when(mockExtensionRequests.getRequestStatus()).thenReturn(mockRequestsStatus);

            List<ExtensionRequestsDTO> extensionRequestsDTO = null;

            extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequestsByLoanPlanId(102);
            assertEquals(1, extensionRequestsDTO.size());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void fetchAllExtensionRequestsByLoanPlanId_Negative() {
        try {
            Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
            when(extensionRequestsRepository.findAllByLoanPlanId(anyInt())).thenReturn(mockExtensionRequestsIterable);
            Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
            when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
            when(mockExtensionRequestsIterator.hasNext()).thenReturn(false);

            List<ExtensionRequestsDTO> extensionRequestsDTO = null;

            extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequestsByLoanPlanId(102);
            assertEquals(0, extensionRequestsDTO.size());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void fetchAllExtensionRequestsByLoanPlanId_Exception() {
        when(extensionRequestsRepository.findAllByLoanPlanId(anyInt())).thenReturn(null);

        assertThrows(IdNotFoundException.class, () -> extensionRequestsServiceImpl.fetchAllExtensionRequestsByLoanPlanId(102));
    }

    @Test
    void fetchAllExtensionRequestsByCustomerId_Positive() {
        try {
            Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
            when(extensionRequestsRepository.findAllByCustomerId(anyInt())).thenReturn(mockExtensionRequestsIterable);
            Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
            when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
            when(mockExtensionRequestsIterator.hasNext()).thenReturn(true).thenReturn(false);
            ExtensionRequests mockExtensionRequests = mock(ExtensionRequests.class);
            when(mockExtensionRequestsIterator.next()).thenReturn(mockExtensionRequests);
            RequestStatus mockRequestsStatus = mock(RequestStatus.class);
            when(mockExtensionRequests.getRequestId()).thenReturn(100);
            when(mockExtensionRequests.getEmiId()).thenReturn(101);
            when(mockExtensionRequests.getCustomerId()).thenReturn(102);
            when(mockExtensionRequests.getLoanPlanId()).thenReturn(103);
            when(mockExtensionRequests.getOtherReason()).thenReturn("non");
            when(mockExtensionRequests.getRequestRaisedOn()).thenReturn(LocalDate.now());
            when(mockExtensionRequests.getEtaPaymentDate()).thenReturn(LocalDate.now().plusWeeks(3));
            when(mockExtensionRequests.getRequestStatus()).thenReturn(mockRequestsStatus);

            List<ExtensionRequestsDTO> extensionRequestsDTO = null;

            extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequestsByCustomerId(102);
            assertEquals(1, extensionRequestsDTO.size());
        } catch (IdNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void fetchAllExtensionRequestsByCustomerId_Negative() {
        try {
            Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
            when(extensionRequestsRepository.findAllByCustomerId(anyInt())).thenReturn(mockExtensionRequestsIterable);
            Iterator<ExtensionRequests> mockExtensionRequestsIterator = mock(Iterator.class);
            when(mockExtensionRequestsIterable.iterator()).thenReturn(mockExtensionRequestsIterator);
            when(mockExtensionRequestsIterator.hasNext()).thenReturn(false);

            List<ExtensionRequestsDTO> extensionRequestsDTO = null;

            extensionRequestsDTO = extensionRequestsServiceImpl.fetchAllExtensionRequestsByCustomerId(102);
            assertEquals(0, extensionRequestsDTO.size());
        } catch (IdNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void fetchAllExtensionRequestsByCustomerId_Exception() {
        Iterable<ExtensionRequests> mockExtensionRequestsIterable = mock(Iterable.class);
        System.out.println(mockExtensionRequestsIterable);
        when(extensionRequestsRepository.findAllByCustomerId(anyInt())).thenReturn(null);

        assertThrows(IdNotFoundException.class, () -> extensionRequestsServiceImpl.fetchAllExtensionRequestsByCustomerId(101));
    }

    @Test
    void insertExtensionRequests_Positive() {
        try {
            ExtensionRequests requests = mock(ExtensionRequests.class);
            ExtensionRequestsDTO requestsDTO = mock(ExtensionRequestsDTO.class);
            when(requestsDTO.getEmiId()).thenReturn(100);
            when(extensionRequestsRepository.save(Mockito.any())).thenReturn(requests);
            when(requests.getRequestId()).thenReturn(100);
            when(requests.getEmiId()).thenReturn(101);
            when(requests.getCustomerId()).thenReturn(102);
            when(requests.getLoanPlanId()).thenReturn(103);
            when(requests.getOtherReason()).thenReturn("non");
            when(requests.getRequestRaisedOn()).thenReturn(LocalDate.now());
            when(requests.getEtaPaymentDate()).thenReturn(LocalDate.now().plusWeeks(3));
            when(requests.getRequestStatus()).thenReturn(RequestStatus.Pending);

            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
            ExtensionReasons extensionReasons = new ExtensionReasons();
            extensionRequestsDTO.setRequestId(100);
            extensionRequestsDTO.setEmiId(101);
            extensionRequestsDTO.setCustomerId(101);
            extensionRequestsDTO.setLoanPlanId(101);
            extensionRequestsDTO.setExtensionsReasons(extensionReasons);
            extensionRequestsDTO.setRequestRaisedOn(LocalDate.now());
            extensionRequestsDTO.setEtaPaymentDate(LocalDate.now().plusWeeks(1));
            extensionRequestsDTO.setRequestStatus(RequestStatus.New);
            ExtensionRequestsDTO newExtensionRequestsDTO = null;

            newExtensionRequestsDTO = extensionRequestsServiceImpl.insertExtensionRequests(extensionRequestsDTO);
            assertEquals(102, newExtensionRequestsDTO.getCustomerId());
        } catch (IdNotValidException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void insertExtensionRequests_Negative() {
        ExtensionRequests requests = mock(ExtensionRequests.class);
        ExtensionRequestsDTO requestsDTO = mock(ExtensionRequestsDTO.class);

        when(requests.getEmiId()).thenReturn(0);
        when(extensionRequestsRepository.save(Mockito.any())).thenReturn(requests);

        ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
        assertThrows(IdNotValidException.class, () -> extensionRequestsServiceImpl.insertExtensionRequests(extensionRequestsDTO));
    }

    @Test
    void insertExtensionRequests_Exception() {
        assertThrows(NullPointerException.class, () -> extensionRequestsServiceImpl.insertExtensionRequests(null));
    }
}