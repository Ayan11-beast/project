package com.cognizant.service;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.ExtensionsRequestResponses;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.repositories.ExtensionRequestsRepository;
import com.cognizant.repositories.ExtensionsRequestResponsesRepository;
import com.cognizant.service.impl.ExtensionsRequestResponsesServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class ExtensionsRequestResponsesServiceImplTest {

    @Mock
    public ExtensionsRequestResponsesRepository extensionsRequestResponsesRepository;

    @Mock
    private ExtensionRequestsRepository extensionRequestsRepository;

    @InjectMocks
    public ExtensionsRequestResponsesServiceImpl extensionsRequestResponsesService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void extensionsRequestsApproval_PositiveApproved() {
        try {

            ExtensionReasons extensionReasons = new ExtensionReasons();
            extensionReasons.setId(100);
            extensionReasons.setReason("Reason 100");

            ExtensionRequests extensionRequests = new ExtensionRequests();
            extensionRequests.setRequestStatus(RequestStatus.New);
            extensionRequests.setRequestId(100);
            extensionRequests.setEmiId(1001);
            extensionRequests.setRequestRaisedOn(LocalDate.now());
            extensionRequests.setEtaPaymentDate(LocalDate.now());
            extensionRequests.setLoanPlanId(102);
            extensionRequests.setCustomerId(103);
            extensionRequests.setExtensionsReasons(extensionReasons);

            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();
            extensionsRequestResponsesDTO.setId(100);
            extensionsRequestResponsesDTO.setResponse("qertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuioqwertyuio");
            extensionsRequestResponsesDTO.setExtensionGranted(true);
            extensionsRequestResponsesDTO.setResponseDate(LocalDate.now().plusWeeks(1));
            extensionsRequestResponsesDTO.setExtensionRequests(extensionRequests);

            ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
            extensionsRequestResponses.setId(100);
            extensionsRequestResponses.setResponse("qertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuioqwertyuio");
            extensionsRequestResponses.setExtensionGranted(true);
            extensionsRequestResponses.setResponseDate(LocalDate.now().plusWeeks(1));
            extensionsRequestResponses.setExtensionRequests(extensionRequests);

            Optional<ExtensionRequests> extensionRequestsOptional = Mockito.mock(Optional.class);
            when(extensionRequestsRepository.findById(Mockito.any())).thenReturn(extensionRequestsOptional);
            when(extensionRequestsOptional.isPresent()).thenReturn(true);
            when(extensionRequestsOptional.get()).thenReturn(extensionRequests);
            when(extensionsRequestResponsesRepository.save(Mockito.any())).thenReturn(extensionsRequestResponses);

            ExtensionsRequestResponsesDTO newExtensionsRequestResponsesDTO = extensionsRequestResponsesService.extensionsRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals(RequestStatus.Approved, newExtensionsRequestResponsesDTO.getExtensionRequests().getRequestStatus());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void extensionsRequestsApproval_PositivePending() {
        try {

            ExtensionReasons extensionReasons = new ExtensionReasons();
            extensionReasons.setId(100);
            extensionReasons.setReason("Reason 100");

            ExtensionRequests extensionRequests = new ExtensionRequests();
            extensionRequests.setRequestStatus(RequestStatus.New);
            extensionRequests.setRequestId(100);
            extensionRequests.setEmiId(1001);
            extensionRequests.setRequestRaisedOn(LocalDate.now());
            extensionRequests.setEtaPaymentDate(LocalDate.now());
            extensionRequests.setLoanPlanId(102);
            extensionRequests.setCustomerId(103);
            extensionRequests.setExtensionsReasons(extensionReasons);

            ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();
            extensionsRequestResponsesDTO.setId(100);
            extensionsRequestResponsesDTO.setResponse("qertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuioqwertyuio");
            extensionsRequestResponsesDTO.setExtensionGranted(false);
            extensionsRequestResponsesDTO.setResponseDate(LocalDate.now().plusWeeks(1));
            extensionsRequestResponsesDTO.setExtensionRequests(extensionRequests);

            ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
            extensionsRequestResponses.setId(100);
            extensionsRequestResponses.setResponse("qertyuiopqwertyuiopqwertyuiopqwertyuiopqwertyuioqwertyuio");
            extensionsRequestResponses.setExtensionGranted(true);
            extensionsRequestResponses.setResponseDate(LocalDate.now().plusWeeks(1));
            extensionsRequestResponses.setExtensionRequests(extensionRequests);

            Optional<ExtensionRequests> extensionRequestsOptional = Mockito.mock(Optional.class);
            when(extensionRequestsRepository.findById(Mockito.any())).thenReturn(extensionRequestsOptional);
            when(extensionRequestsOptional.isPresent()).thenReturn(true);
            when(extensionRequestsOptional.get()).thenReturn(extensionRequests);
            when(extensionsRequestResponsesRepository.save(Mockito.any())).thenReturn(extensionsRequestResponses);

            ExtensionsRequestResponsesDTO newExtensionsRequestResponsesDTO = extensionsRequestResponsesService.extensionsRequestsApproval(100, extensionsRequestResponsesDTO);
            assertEquals(RequestStatus.Pending, newExtensionsRequestResponsesDTO.getExtensionRequests().getRequestStatus());
        } catch (IdNotFoundException e) {
            fail(e.getMessage());
        }
    }

    @Test
    void extensionsRequestsApproval_NegativeException() {

        ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();

        Optional<ExtensionRequests> extensionRequestsOptional = Mockito.mock(Optional.class);
        when(extensionRequestsRepository.findById(Mockito.any())).thenReturn(extensionRequestsOptional);
        when(extensionRequestsOptional.isPresent()).thenReturn(false);

        assertThrows(IdNotFoundException.class, () -> extensionsRequestResponsesService.extensionsRequestsApproval(100, extensionsRequestResponsesDTO));
    }

}