package com.cognizant.service;

import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.repositories.ExtensionReasonsRepository;
import com.cognizant.service.impl.ExtensionReasonsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

class ExtensionReasonsServiceImplTest {

    @Mock
    ExtensionReasonsRepository extensionReasonsRepository;

    @InjectMocks
    ExtensionReasonsServiceImpl extensionReasonsServiceImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void fetchAllExtensionReasons_Positive() {
        try {
            Iterable<ExtensionReasons> mockExtensionReasonsIterable = Mockito.mock(Iterable.class);
            when(extensionReasonsRepository.findAll()).thenReturn(mockExtensionReasonsIterable);
            Iterator<ExtensionReasons> mockExtensionReasonsIterator = Mockito.mock(Iterator.class);
            when(mockExtensionReasonsIterable.iterator()).thenReturn(mockExtensionReasonsIterator);
            when(mockExtensionReasonsIterator.hasNext()).thenReturn(true).thenReturn(false);
            ExtensionReasons mockExtensionReasons = Mockito.mock(ExtensionReasons.class);
            when(mockExtensionReasonsIterator.next()).thenReturn(mockExtensionReasons);
            when(mockExtensionReasons.getId()).thenReturn(100);
            when(mockExtensionReasons.getReason()).thenReturn("no reason");

            List<ExtensionReasonsDTO> extensionReasonsList = extensionReasonsServiceImpl.fetchAllExtensionReasons();
            assertEquals(1, extensionReasonsList.size());
        } catch (Exception e) {
            assertTrue(false);
        }
    }

    @Test
    void fetchAllExtensionReasons_Negative() {
        try {
            Iterable<ExtensionReasons> mockExtensionReasonsIterable = Mockito.mock(Iterable.class);
            when(extensionReasonsRepository.findAll()).thenReturn(mockExtensionReasonsIterable);
            Iterator<ExtensionReasons> mockExtensionReasonsIterator = Mockito.mock(Iterator.class);
            when(mockExtensionReasonsIterable.iterator()).thenReturn(mockExtensionReasonsIterator);
            when(mockExtensionReasonsIterator.hasNext()).thenReturn(false);
            ExtensionReasons mockExtensionReasons = Mockito.mock(ExtensionReasons.class);
            when(mockExtensionReasonsIterator.next()).thenReturn(mockExtensionReasons);
            when(mockExtensionReasons.getId()).thenReturn(100);
            when(mockExtensionReasons.getReason()).thenReturn("no reason");

            List<ExtensionReasonsDTO> extensionReasonsList = extensionReasonsServiceImpl.fetchAllExtensionReasons();
            assertEquals(0, extensionReasonsList.size());
        } catch (Exception e) {
            assertTrue(false);
        }
    }
}