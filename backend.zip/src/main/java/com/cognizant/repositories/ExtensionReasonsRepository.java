package com.cognizant.repositories;

import com.cognizant.entities.ExtensionReasons;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author Tanmay Sharma
 * This repository interact with extension reason table present in database.
 */
@Repository
public interface ExtensionReasonsRepository extends CrudRepository<ExtensionReasons, Integer> {

}
