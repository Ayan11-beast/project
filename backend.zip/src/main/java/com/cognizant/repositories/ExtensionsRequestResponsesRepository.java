package com.cognizant.repositories;

import com.cognizant.entities.ExtensionsRequestResponses;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author Tanmay Sharma
 * This repository interact with extension response's request table present in database.
 */
@Repository
public interface ExtensionsRequestResponsesRepository extends CrudRepository<ExtensionsRequestResponses, Integer> {

}
