package com.cognizant.repositories;

import com.cognizant.entities.ExtensionRequests;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author Tanmay Sharma
 * This repository interact with extension request table present in database.
 */
@Repository
public interface ExtensionRequestsRepository extends CrudRepository<ExtensionRequests, Integer> {

    Iterable<ExtensionRequests> findAllByCustomerId(int customerId);

    Iterable<ExtensionRequests> findAllByLoanPlanId(int loanPlanId);

}
