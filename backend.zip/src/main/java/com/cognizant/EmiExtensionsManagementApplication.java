package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This is main class of the Spring Boot Application
 */
@SpringBootApplication
//@EnableDiscoveryClient(autoRegister = true)
public class EmiExtensionsManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmiExtensionsManagementApplication.class, args);
    }

}
