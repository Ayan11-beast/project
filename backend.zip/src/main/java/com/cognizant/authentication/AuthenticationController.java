package com.cognizant.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("api/authenticate")
@CrossOrigin("http://localhost:4200/")
public class AuthenticationController {

    private AuthenticationService authenticationService;

    @Autowired
    AuthenticationController(AuthenticationService authenticationService){
        this.authenticationService = authenticationService;
    }

    @PostMapping
    public ResponseEntity<?> authenticateUser(@RequestBody AuthenticationEntity authenticationEntity){
        AuthenticationEntity newAuthenticationEntity = authenticationService.authenticateUser(authenticationEntity.getUserName(),authenticationEntity.getPassword());
        if(newAuthenticationEntity.getUserName()!=null){
            return new ResponseEntity<AuthenticationEntity>(newAuthenticationEntity, HttpStatus.ACCEPTED);
        }
            return new ResponseEntity<>("Wrong Credentials",HttpStatus.FORBIDDEN);
    }
}
