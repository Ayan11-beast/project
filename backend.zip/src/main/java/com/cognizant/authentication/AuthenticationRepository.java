package com.cognizant.authentication;

import org.springframework.data.repository.CrudRepository;

public interface AuthenticationRepository extends CrudRepository<AuthenticationEntity,String> {
}
