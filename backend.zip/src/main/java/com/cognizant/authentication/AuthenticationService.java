package com.cognizant.authentication;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthenticationService {

    private AuthenticationRepository authenticationRepository;

    @Autowired
    AuthenticationService(AuthenticationRepository authenticationRepository){
        this.authenticationRepository = authenticationRepository;
    }

    public AuthenticationEntity authenticateUser(String userName, String password){
        List<AuthenticationEntity> authenticationEntityList = (List<AuthenticationEntity>) authenticationRepository.findAll();
        AuthenticationEntity authenticationEntity = new AuthenticationEntity();
        for(AuthenticationEntity authentication:authenticationEntityList){
            if(authentication.getUserName().equals(userName) && authentication.getPassword().equals(password)){
                authenticationEntity.setUserName(authentication.getUserName());
                authenticationEntity.setPassword(authentication.getPassword());
                authenticationEntity.setRole(authentication.getRole());
            }
        }
        return authenticationEntity;
    }
}
