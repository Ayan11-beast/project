package com.cognizant.exceptions;

/**
 * @Author Tanmay Sharma
 * This is custom exception thrown when maximum number of extensions limit is reached.
 */
public class MaximumExtensionsLimitReachedException extends Exception {
    public MaximumExtensionsLimitReachedException(String message) {
        super(message);
    }
}
