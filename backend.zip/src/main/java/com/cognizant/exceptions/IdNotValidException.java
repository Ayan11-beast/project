package com.cognizant.exceptions;

/**
 * @Author Tanmay Sharma
 * This is custom exception thrown when the id in request body is valid.
 */
public class IdNotValidException extends Exception {
    public IdNotValidException(String message) {
        super(message);
    }
}
