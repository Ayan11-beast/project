package com.cognizant.exceptions;

/**
 * @Author Tanmay Sharma
 * This is custom exception thrown when data for the id is not present.
 */
public class IdNotFoundException extends Exception {
    public IdNotFoundException(String message) {
        super(message);
    }
}
