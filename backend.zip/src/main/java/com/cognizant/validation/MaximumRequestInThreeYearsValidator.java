package com.cognizant.validation;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.service.ExtensionRequestsService;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a custom validation annotation class that check
 * if number of extension request is in limit in three years
 */
@Component
public class MaximumRequestInThreeYearsValidator implements ConstraintValidator<ValidateMaximumRequestInThreeYears, Integer> {

    @Autowired
    ExtensionRequestsService extensionRequestsService;

    @Override
    public void initialize(ValidateMaximumRequestInThreeYears constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        List<ExtensionRequestsDTO> extensionRequestsDTOList = null;
        try {
            extensionRequestsDTOList = extensionRequestsService.fetchAllExtensionRequestsByCustomerId(value);
        } catch (IdNotFoundException e) {
            throw new RuntimeException(e);
        }
        List<ExtensionRequestsDTO> newExtensionRequestsDTOList = new ArrayList<>();
        LocalDate date = LocalDate.now().minusYears(3);
        for (ExtensionRequestsDTO list : extensionRequestsDTOList) {
            LocalDate raisedOnDate = list.getRequestRaisedOn();
            if (raisedOnDate.isAfter(date) || raisedOnDate.isEqual(date)) {
                newExtensionRequestsDTOList.add(list);
            }
        }
        return newExtensionRequestsDTOList.size() <= 5;
    }
}
