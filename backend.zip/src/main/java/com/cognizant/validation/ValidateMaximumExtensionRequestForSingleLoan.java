package com.cognizant.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * This is a custom validation annotation.
 */
@Constraint(validatedBy = MaximumExtensionRequestForSingleLoanValidator.class)
@Retention(RUNTIME)
@Target(FIELD)
public @interface ValidateMaximumExtensionRequestForSingleLoan {
    String message() default "Customer is allowed to have a maximum of 3 extension requests in a single loan.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
