package com.cognizant.validation;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.MaximumExtensionsLimitReachedException;
import com.cognizant.service.ExtensionRequestsService;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a custom validation annotation class that check
 * if number of extension request is in limit in a single year
 */
@Component
public class MaximumExtensionRequestForSingleLoanValidator implements ConstraintValidator<ValidateMaximumExtensionRequestForSingleLoan, Integer> {

    @Autowired
    ExtensionRequestsService extensionRequestsService;

    @Override
    public void initialize(ValidateMaximumExtensionRequestForSingleLoan constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        List<ExtensionRequestsDTO> extensionRequestsDTOList = null;
        try {
            extensionRequestsDTOList = extensionRequestsService.fetchAllExtensionRequestsByLoanPlanId(value);
        } catch (IdNotFoundException e) {
            return false;
        }
        List<ExtensionRequestsDTO> newExtensionRequestsDTOList = new ArrayList<>();
        LocalDate lastYearDate = LocalDate.now().minusYears(1);
        extensionRequestsDTOList.forEach(extensionRequestsDTO ->{
            if(extensionRequestsDTO.getRequestRaisedOn().isAfter(lastYearDate) || extensionRequestsDTO.getRequestRaisedOn().isEqual(lastYearDate)){
                newExtensionRequestsDTOList.add(extensionRequestsDTO);
            }
        });
        if (newExtensionRequestsDTOList.size() > 3) {
            try {
                throw new MaximumExtensionsLimitReachedException("Number of Extensions have reached limit.");
            } catch (MaximumExtensionsLimitReachedException e) {
                return false;
            }
        }
        return true;
    }
}
