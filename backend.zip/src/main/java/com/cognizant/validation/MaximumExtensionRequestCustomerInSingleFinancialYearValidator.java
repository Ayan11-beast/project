package com.cognizant.validation;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.MaximumExtensionsLimitReachedException;
import com.cognizant.service.ExtensionRequestsService;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * This is a custom validation annotation class that check
 * if number of extension request is in limit in a single year
 */
@Component
public class MaximumExtensionRequestCustomerInSingleFinancialYearValidator implements ConstraintValidator<ValidateMaximumExtensionRequestForCustomerInSingleFinancialYear,Integer> {

    @Autowired
    ExtensionRequestsService extensionRequestsService;

    @Override
    public void initialize(ValidateMaximumExtensionRequestForCustomerInSingleFinancialYear constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
        List<ExtensionRequestsDTO> extensionRequestsDTOList = null;
        try {
            extensionRequestsDTOList = extensionRequestsService.fetchAllExtensionRequestsByCustomerId(value);
        } catch (IdNotFoundException e) {
            throw new RuntimeException(e);
        }
        List<ExtensionRequestsDTO> newExtensionRequestsDTOList = new ArrayList<>();
        int CurrentYear = Calendar.getInstance().get(Calendar.YEAR);
        int CurrentMonth = (Calendar.getInstance().get(Calendar.MONTH)+1);
        LocalDate financialYearFrom;
        LocalDate financialYearTo;
        if (CurrentMonth<4) {
            financialYearFrom=LocalDate.of((CurrentYear-1),04,01);
            financialYearTo=LocalDate.of((CurrentYear),03,31);
        } else {
            financialYearFrom=LocalDate.of((CurrentYear),04,01);
            financialYearTo=LocalDate.of((CurrentYear+1),03,31);
        }
        for (ExtensionRequestsDTO list : extensionRequestsDTOList) {
            LocalDate raisedOnDate = list.getRequestRaisedOn();
            if (raisedOnDate.isAfter(financialYearFrom) || raisedOnDate.isEqual(financialYearFrom)|| raisedOnDate.isEqual(financialYearTo)|| raisedOnDate.isBefore(financialYearTo) ) {
                newExtensionRequestsDTOList.add(list);
            }
        }
        return newExtensionRequestsDTOList.size() <= 1;
    }
}
