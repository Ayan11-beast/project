package com.cognizant.dto;

import com.cognizant.entities.ExtensionRequests;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author Tanmay Sharma
 * This DTO is used as request body and response body in extension request's response controller.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExtensionsRequestResponsesDTO {

    private int id;

    @NotBlank(message = "{com.cognizant.dto.ExtensionsRequestResponsesDTO.response.error}")
    @Size(min = 50, message = "{com.cognizant.dto.ExtensionsRequestResponsesDTO.response.Size.error}")
    private String response;

    @NotNull(message = "{com.cognizant.dto.ExtensionsRequestResponsesDTO.isExtensionGranted.error}")
    private boolean extensionGranted;

    @NotNull(message = "{com.cognizant.dto.ExtensionsRequestResponsesDTO.responseDate.error}")
    @FutureOrPresent(message = "{om.cognizant.dto.ExtensionsRequestResponsesDTO.responseDate.FutureOrPresent.error}")
    private LocalDate responseDate;

    @NotNull(message = "{com.cognizant.dto.ExtensionsRequestResponsesDTO.extensionRequests.error}")
    private ExtensionRequests extensionRequests;

}
