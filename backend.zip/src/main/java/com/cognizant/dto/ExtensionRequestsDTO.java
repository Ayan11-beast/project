package com.cognizant.dto;

import com.cognizant.entities.ExtensionReasons;
import com.cognizant.entities.RequestStatus;
import com.cognizant.validation.ValidateMaximumExtensionRequestForCustomerInSingleFinancialYear;
import com.cognizant.validation.ValidateMaximumExtensionRequestForSingleLoan;
import com.cognizant.validation.ValidateMaximumRequestInThreeYears;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author Tanmay Sharma
 * This DTO is used as request body and response body in extension request controller.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExtensionRequestsDTO {

    private int requestId;

    @Positive(message = "{com.cognizant.dto.ExtensionRequestsDTO.emiId.error}")
    private int emiId;

    @Positive(message = "{com.cognizant.dto.ExtensionRequestsDTO.customerId.error}")
    @ValidateMaximumExtensionRequestForCustomerInSingleFinancialYear(message = "{com.cognizant.dto.ExtensionRequestsDTO.customerId.ValidateMaximumExtensionRequestForCustomerInSingleFinancialYear.error}")
    @ValidateMaximumRequestInThreeYears(message = "{com.cognizant.dto.ExtensionRequestsDTO.customerId.ValidateMaximumRequestInThreeYears.error}")
    private int customerId;

    @Positive(message = "{com.cognizant.dto.ExtensionRequestsDTO.loanPlanId.error}")
    @ValidateMaximumExtensionRequestForSingleLoan(message = "{com.cognizant.dto.ExtensionRequestsDTO.loanPlanId.ValidateMaximumExtensionRequestForSingleLoan.error}")
    private int loanPlanId;

    private String otherReason;

    @NotNull(message = "{com.cognizant.dto.ExtensionRequestsDTO.requestRaisedOn.FutureOrPresent.error}")
    private LocalDate requestRaisedOn = LocalDate.now();

    @NotNull(message = "{com.cognizant.dto.ExtensionRequestsDTO.etaPaymentDate.error}")
    @Future(message = "{com.cognizant.dto.ExtensionRequestsDTO.etaPaymentDate.Future.error}")
    private LocalDate etaPaymentDate;

    @NotNull(message = "{com.cognizant.dto.ExtensionRequestsDTO.requestStatus.error}")
    private RequestStatus requestStatus;

    @NotNull(message = "{com.cognizant.dto.ExtensionRequestsDTO.extensionsReasons.error}")
    private ExtensionReasons extensionsReasons;

}
