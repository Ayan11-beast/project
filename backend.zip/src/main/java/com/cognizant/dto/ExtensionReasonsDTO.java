package com.cognizant.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author Tanmay Sharma
 * This DTO is used as request body and response body in extension reason controller.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExtensionReasonsDTO {

    private int id;

    private String reason;

}
