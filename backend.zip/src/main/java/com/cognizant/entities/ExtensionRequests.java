package com.cognizant.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author Tanmay Sharma
 * This entity is for extension requests repository.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Extension_Requests")
public class ExtensionRequests {

    @Id
    @Column(name = "Request_Id")
    private int requestId;

    @Column(name = "EMIs_Id")
    private int emiId;

    @Column(name = "Customer_ID")
    private int customerId;

    @Column(name = "Loan_Plan_ID")
    private int loanPlanId;

    @ManyToOne
    @JoinColumn(name = "Extension_Reasons_Id", referencedColumnName = "Id")
    private ExtensionReasons extensionsReasons;

    @Column(name = "Other_Reason")
    private String otherReason;

    @Column(name = "Request_Raised_On")
    private LocalDate requestRaisedOn;

    @Column(name = "ETA_Payment_Date")
    private LocalDate etaPaymentDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "Request_Status")
    private RequestStatus requestStatus = RequestStatus.New;

}
