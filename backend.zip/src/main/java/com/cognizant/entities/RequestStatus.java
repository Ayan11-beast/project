package com.cognizant.entities;

/**
 * @Author Tanmay Sharma
 * This enum contains recommended Request status.
 */
public enum RequestStatus {
    Pending,
    Approved,
    New
}
