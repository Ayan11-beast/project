package com.cognizant.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author Tanmay Sharma
 * This entity is for extension request's response repository.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Extensions_Request_Responses")
public class ExtensionsRequestResponses {

    @Id
    @Column(name = "Id")
    private int id;

    @Column(name = "Response")
    private String response;

    @Column(name = "Is_Extension_Granted")
    private boolean extensionGranted;

    @Column(name = "Response_Date")
    private LocalDate responseDate;

    @OneToOne
    @JoinColumn(name = "Extension_Request_Id", referencedColumnName = "Request_Id")
    private ExtensionRequests extensionRequests;

}
