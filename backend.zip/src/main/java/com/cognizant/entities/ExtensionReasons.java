package com.cognizant.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author Tanmay Sharma
 * This entity is for extension reason repository.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Extension_Reasons")
public class ExtensionReasons {

    @Id
    @Column(name = "Id")
    private int id;

    @Column(name = "Reason")
    private String reason;

}
