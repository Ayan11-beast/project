package com.cognizant.controller;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.IdNotValidException;
import com.cognizant.service.impl.ExtensionRequestsServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author Tanmay Sharma
 * This controller is handle all request related to extension requests.
 */
@RestController
@CrossOrigin("http://localhost:4200/")
@RequestMapping("api/emiextensions")
public class ExtensionRequestsController {

    ExtensionRequestsServiceImpl extensionRequestsService;

    @Autowired
    public ExtensionRequestsController(ExtensionRequestsServiceImpl extensionRequestsService) {
        this.extensionRequestsService = extensionRequestsService;
    }

    /**
     * This controller method create a new extension request for EMI of a customer.
     *
     * @return
     * @RequestBody extensionRequestsDTO
     */
    @Operation(description = "Raise new request for the emi extension")
    @PostMapping("newrequest")
    public ResponseEntity<?> raiseNewRequest(
            @Valid @RequestBody ExtensionRequestsDTO extensionRequestsDTO) {
        try {
            ExtensionRequestsDTO newExtensionRequestsDTO = extensionRequestsService.insertExtensionRequests(extensionRequestsDTO);
            if (newExtensionRequestsDTO.getEmiId() != 0) {
                return new ResponseEntity<>("Data inserted successfully.", HttpStatus.CREATED);
            }
            return new ResponseEntity<>("Error occurred during inserting data.", HttpStatus.BAD_REQUEST);
        } catch (IdNotValidException | NullPointerException e) {
            return new ResponseEntity<>("Error occurred during inserting data.", HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * This controller method fetch all the EMI extension request present in the table.
     *
     * @return
     */
    @Operation(description = "Fetch all the extension requests present.")
    @GetMapping
    public ResponseEntity<?> getNewExtensionRequests() {
        List<ExtensionRequestsDTO> extensionRequestsDTOList = extensionRequestsService.fetchAllExtensionRequests();
        if (!extensionRequestsDTOList.isEmpty()) {
            return new ResponseEntity<>(extensionRequestsDTOList, HttpStatus.OK);
        }
        return new ResponseEntity<>("No data found.", HttpStatus.NOT_FOUND);
    }

    /**
     * This controller method fetch a single EMI extension request for a particular id.
     *
     * @param requestId
     * @return
     */
    @Operation(description = "Fetch a extension request with specific id.")
    @GetMapping("{requestId}")
    public ResponseEntity<?> getNewExtensionRequestsById(@PathVariable int requestId) {
        try {
            ExtensionRequestsDTO extensionRequestsDTO = extensionRequestsService.fetchExtensionRequestsById(requestId);
            if (extensionRequestsDTO.getRequestId() != 0) {
                return new ResponseEntity<>(extensionRequestsDTO, HttpStatus.OK);
            }
            return new ResponseEntity<>("Error occurred while fetching data.", HttpStatus.NOT_FOUND);
        } catch (IdNotFoundException e) {
            return new ResponseEntity<>("No data found for the given id.", HttpStatus.NOT_FOUND);
        }
    }

}