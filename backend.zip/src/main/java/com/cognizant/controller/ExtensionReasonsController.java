package com.cognizant.controller;

import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.service.impl.ExtensionReasonsServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author Tanmay Sharma
 * This controller handle request related to Extension Reasons.
 */
@RestController
@CrossOrigin("http://localhost:4200/")
@RequestMapping("api/emiextensions/reasons")
public class ExtensionReasonsController {

    private ExtensionReasonsServiceImpl extensionReasonsService;

    @Autowired
    public ExtensionReasonsController(ExtensionReasonsServiceImpl extensionReasonsService) {
        this.extensionReasonsService = extensionReasonsService;
    }

    /**
     * This controller method fetch all extension reason present.
     * @return
     */
    @Operation(description = "Fetch all extension reasons present")
    @GetMapping
    public ResponseEntity<?> getExtensionReasons() {
        List<ExtensionReasonsDTO> extensionReasonsDTOList = extensionReasonsService.fetchAllExtensionReasons();
        if (!extensionReasonsDTOList.isEmpty()) {
            return new ResponseEntity<>(extensionReasonsDTOList, HttpStatus.OK);
        }
        return new ResponseEntity<>("No record found.", HttpStatus.NOT_FOUND);
    }
}
