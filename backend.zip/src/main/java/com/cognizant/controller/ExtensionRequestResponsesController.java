package com.cognizant.controller;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.service.impl.ExtensionsRequestResponsesServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @Author Tanmay Sharma
 * This controller is handle all request related to extension request's response
 */
@RestController
@CrossOrigin("http://localhost:4200/")
@RequestMapping("api/emiextensions")
public class ExtensionRequestResponsesController {

    private ExtensionsRequestResponsesServiceImpl extensionsRequestResponsesService;

    @Autowired
    public ExtensionRequestResponsesController(ExtensionsRequestResponsesServiceImpl extensionsRequestResponsesService) {
        this.extensionsRequestResponsesService = extensionsRequestResponsesService;
    }

    /**
     * This controller method update the approval status according to response given by manager.
     *
     * @param requestId
     * @return
     * @RequestBody extensionsRequestResponsesDTO
     */
    @Operation(description = "Update the approval status according to response given by manager.")
    @PutMapping(value = "{requestId}")
    public ResponseEntity<?> updateExtensionRequestsApproval(
            @PathVariable int requestId,
            @Valid @RequestBody ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO) {
        try {
            ExtensionsRequestResponsesDTO newExtensionsRequestResponsesDTO = extensionsRequestResponsesService.extensionsRequestsApproval(requestId, extensionsRequestResponsesDTO);
            if (newExtensionsRequestResponsesDTO.getId() != 0) {
                return new ResponseEntity<>("Updated successfully.", HttpStatus.OK);
            }
            return new ResponseEntity<>("Error occurred while updating.", HttpStatus.BAD_REQUEST);
        } catch (IdNotFoundException e) {
            return new ResponseEntity<>("No data found for the given id.", HttpStatus.NOT_FOUND);
        }
    }
}
