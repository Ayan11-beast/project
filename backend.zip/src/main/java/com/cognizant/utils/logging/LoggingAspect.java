package com.cognizant.utils.logging;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class LoggingAspect {
    @Before(" execution(* com.cognizant.*.*.*(..))")
    public void beforeAdvice(JoinPoint joinPoint){
        log.info("Info: " + joinPoint.getSignature().getName());
    }

    @After(" execution(* com.cognizant.*.*.*(..))")
    public void afterAdvice(JoinPoint joinPoint){
        log.info("Info: " + joinPoint.getSignature().getName());
    }

    @AfterReturning(pointcut = " execution(* com.cognizant.*.*.*(..))", returning = "result")
    public void afterReturningAdvice(JoinPoint joinPoint,Object result){
        log.info("Info: " + joinPoint.getSignature().getName() + "Return Value: " + result);
    }

    @AfterThrowing(pointcut = " execution(* com.cognizant.*.*.*(..))", throwing = "error")
    public void afterThrowingAdvice(JoinPoint joinPoint,Throwable error){
        log.info("Info: " + joinPoint.getSignature().getName() + "Exception Thrown: " + error);
    }

    @Pointcut(" execution(* com.cognizant.*.*.*(..))")
    public void getPointCut() {}
    @Around("getPointCut()")
    public Object aroundAdvice(ProceedingJoinPoint point) {
        log.info("Info: "+point.getSignature().getName());
        Object returnValue=null;
        try {
            returnValue=point.proceed();
        } catch (Throwable e) {
            log.error("Error:"+e.getMessage());
        }
        log.debug("Debug: "+returnValue);
        return returnValue;
    }
}
