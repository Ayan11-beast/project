package com.cognizant.utils.mappers;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.entities.ExtensionsRequestResponses;
import com.cognizant.service.impl.ExtensionsRequestResponsesServiceImpl;

import java.util.Random;

/**
 * @Author Tanmay Sharma
 * This is custom mapper to convert ExtensionRequestsReasonDTO to ExtensionRequestsReason entity and vice-versa.
 */
public class ExtensionsRequestResponsesServiceMapper {

    /**
     * This method in custom mapper convert extension request's response DTO to extension request's response entity
     *
     * @param extensionsRequestResponsesDTO
     * @return
     */
    public static ExtensionsRequestResponses convertToExtensionsRequestResponses(ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO) {
        ExtensionsRequestResponses extensionsRequestResponses = new ExtensionsRequestResponses();
        extensionsRequestResponses.setId(generatedUniqueId());
        extensionsRequestResponses.setExtensionGranted(extensionsRequestResponsesDTO.isExtensionGranted());
        extensionsRequestResponses.setResponseDate(extensionsRequestResponsesDTO.getResponseDate());
        extensionsRequestResponses.setResponse(extensionsRequestResponsesDTO.getResponse());
        extensionsRequestResponses.setExtensionRequests(extensionsRequestResponsesDTO.getExtensionRequests());
        return extensionsRequestResponses;
    }

    /**
     * This method in custom mapper convert extension request's response entity to extension request's response DTO
     *
     * @param extensionsRequestResponses
     * @return
     */
    public static ExtensionsRequestResponsesDTO convertToExtensionsRequestResponsesDTO(ExtensionsRequestResponses extensionsRequestResponses) {
        ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO = new ExtensionsRequestResponsesDTO();
        extensionsRequestResponsesDTO.setId(extensionsRequestResponses.getId());
        extensionsRequestResponsesDTO.setExtensionGranted(extensionsRequestResponses.isExtensionGranted());
        extensionsRequestResponsesDTO.setResponseDate(extensionsRequestResponses.getResponseDate());
        extensionsRequestResponsesDTO.setResponse(extensionsRequestResponses.getResponse());
        extensionsRequestResponsesDTO.setExtensionRequests(extensionsRequestResponses.getExtensionRequests());

        return extensionsRequestResponsesDTO;
    }

    /**
     * This method in custom mapper generate unique id for id in extension request response.
     * @return
     */
    public static int generatedUniqueId() {
        int[] result = new Random().ints(1_000_000, 99_999_99)
                .distinct()
                .limit(1)
                .toArray();
        return result[0];
    }

}
