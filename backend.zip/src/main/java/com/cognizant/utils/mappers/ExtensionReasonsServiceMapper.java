package com.cognizant.utils.mappers;

import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.entities.ExtensionReasons;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @Author Tanmay Sharma
 * This is custom mapper to convert ExtensionReasonDTO to ExtensionReason entity and vice-versa.
 */
public class ExtensionReasonsServiceMapper {

    /**
     * This method in custom mapper convert list of extension reason entity to list of extension reason DTO
     *
     * @param extensionReasonsIterator
     * @return
     */
    public static List<ExtensionReasonsDTO> convertToExtensionReasonsDTOList(Iterator<ExtensionReasons> extensionReasonsIterator) {

        List<ExtensionReasonsDTO> extensionReasonsDTOList = new ArrayList<>();
        while (extensionReasonsIterator.hasNext()) {
            ExtensionReasons extensionReasons = extensionReasonsIterator.next();
            ExtensionReasonsDTO extensionReasonsDTO = new ExtensionReasonsDTO();
            extensionReasonsDTO.setId(extensionReasons.getId());
            extensionReasonsDTO.setReason(extensionReasons.getReason());
            extensionReasonsDTOList.add(extensionReasonsDTO);
        }
        return extensionReasonsDTOList;
    }

    /**
     * This method in custom mapper convert list of extension reason DTO to list of extension reason entity
     *
     * @param extensionReasonsDTOIterator
     * @return
     */
    public static List<ExtensionReasons> convertToExtensionReasonsList(Iterator<ExtensionReasonsDTO> extensionReasonsDTOIterator) {

        List<ExtensionReasons> extensionReasonsList = new ArrayList<>();
        while (extensionReasonsDTOIterator.hasNext()) {
            ExtensionReasonsDTO extensionReasonsDTO = extensionReasonsDTOIterator.next();
            ExtensionReasons extensionReasons = new ExtensionReasons();
            extensionReasons.setId(extensionReasonsDTO.getId());
            extensionReasons.setReason(extensionReasonsDTO.getReason());
            extensionReasonsList.add(extensionReasons);
        }
        return extensionReasonsList;
    }

}
