package com.cognizant.utils.mappers;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.service.impl.ExtensionRequestsServiceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * @Author Tanmay Sharma
 * This is custom mapper to convert ExtensionRequestsDTO to ExtensionRequests entity and vice-versa.
 */
public class ExtensionRequestsServiceMapper {

    /**
     * This method in custom mapper convert list of extension request DTO to list of extension request entity
     *
     * @param extensionRequestsIterator
     * @return
     */
    public static List<ExtensionRequestsDTO> convertToExtensionRequestsDTOList(Iterator<ExtensionRequests> extensionRequestsIterator) {
        List<ExtensionRequestsDTO> extensionRequestsDtoList = new ArrayList<>();
        while (extensionRequestsIterator.hasNext()) {
            ExtensionRequests extensionRequest = extensionRequestsIterator.next();
            ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
            extensionRequestsDTO.setRequestId(extensionRequest.getRequestId());
            extensionRequestsDTO.setEmiId(extensionRequest.getEmiId());
            extensionRequestsDTO.setCustomerId(extensionRequest.getCustomerId());
            extensionRequestsDTO.setLoanPlanId(extensionRequest.getLoanPlanId());
            extensionRequestsDTO.setOtherReason(extensionRequest.getOtherReason());
            extensionRequestsDTO.setRequestRaisedOn(extensionRequest.getRequestRaisedOn());
            extensionRequestsDTO.setEtaPaymentDate(extensionRequest.getEtaPaymentDate());
            extensionRequestsDTO.setRequestStatus(extensionRequest.getRequestStatus());
            extensionRequestsDTO.setExtensionsReasons(extensionRequest.getExtensionsReasons());
            extensionRequestsDtoList.add(extensionRequestsDTO);
        }
        return extensionRequestsDtoList;
    }

    /**
     * This method in custom mapper convert list of extension request entity to list of extension request DTO
     *
     * @param extensionRequestsDTOIterator
     * @return
     */
    public static List<ExtensionRequests> convertToExtensionRequestsList(Iterator<ExtensionRequestsDTO> extensionRequestsDTOIterator) {
        List<ExtensionRequests> extensionRequestsList = new ArrayList<>();
        while (extensionRequestsDTOIterator.hasNext()) {
            ExtensionRequestsDTO extensionRequestsDTO = extensionRequestsDTOIterator.next();
            ExtensionRequests extensionRequests = new ExtensionRequests();
            extensionRequests.setRequestId(extensionRequestsDTO.getRequestId());
            extensionRequests.setEmiId(extensionRequestsDTO.getEmiId());
            extensionRequests.setCustomerId(extensionRequestsDTO.getCustomerId());
            extensionRequests.setLoanPlanId(extensionRequestsDTO.getLoanPlanId());
            extensionRequests.setOtherReason(extensionRequestsDTO.getOtherReason());
            extensionRequests.setRequestRaisedOn(extensionRequestsDTO.getRequestRaisedOn());
            extensionRequests.setEtaPaymentDate(extensionRequestsDTO.getEtaPaymentDate());
            extensionRequests.setRequestStatus(extensionRequestsDTO.getRequestStatus());
            extensionRequests.setExtensionsReasons(extensionRequestsDTO.getExtensionsReasons());
            extensionRequestsList.add(extensionRequests);
        }
        return extensionRequestsList;
    }

    /**
     * This method in custom mapper convert extension request entity to extension request DTO
     *
     * @param extensionRequests
     * @return
     */
    public static ExtensionRequestsDTO convertToExtensionRequestsDTO(ExtensionRequests extensionRequests) {

        ExtensionRequestsDTO extensionRequestsDTO = new ExtensionRequestsDTO();
        extensionRequestsDTO.setRequestId(extensionRequests.getRequestId());
        extensionRequestsDTO.setEmiId(extensionRequests.getEmiId());
        extensionRequestsDTO.setCustomerId(extensionRequests.getCustomerId());
        extensionRequestsDTO.setLoanPlanId(extensionRequests.getLoanPlanId());
        extensionRequestsDTO.setOtherReason(extensionRequests.getOtherReason());
        extensionRequestsDTO.setRequestRaisedOn(extensionRequests.getRequestRaisedOn());
        extensionRequestsDTO.setEtaPaymentDate(extensionRequests.getEtaPaymentDate());
        extensionRequestsDTO.setRequestStatus(extensionRequests.getRequestStatus());
        extensionRequestsDTO.setExtensionsReasons(extensionRequests.getExtensionsReasons());

        return extensionRequestsDTO;
    }

    /**
     * This method in custom mapper convert extension request DTO to extension request entity
     *
     * @param extensionRequestsDTO
     * @return
     */
    public static ExtensionRequests convertToExtensionRequests(ExtensionRequestsDTO extensionRequestsDTO) {

        ExtensionRequests extensionRequests = new ExtensionRequests();
        extensionRequests.setRequestId(generatedUniqueRequestId());
        extensionRequests.setEmiId(extensionRequestsDTO.getEmiId());
        extensionRequests.setCustomerId(extensionRequestsDTO.getCustomerId());
        extensionRequests.setLoanPlanId(extensionRequestsDTO.getLoanPlanId());
        extensionRequests.setOtherReason(extensionRequestsDTO.getOtherReason());
        extensionRequests.setRequestRaisedOn(extensionRequestsDTO.getRequestRaisedOn());
        extensionRequests.setEtaPaymentDate(extensionRequestsDTO.getEtaPaymentDate());
        extensionRequests.setRequestStatus(extensionRequestsDTO.getRequestStatus());
        extensionRequests.setExtensionsReasons(extensionRequestsDTO.getExtensionsReasons());

        return extensionRequests;
    }

    /**
     * This method in custom mapper generate unique id for id in extension request.
     *
     * @return
     */
    public static int generatedUniqueRequestId() {
        int[] result = new Random().ints(10_000_000, 999_999_99)
                .distinct()
                .limit(1)
                .toArray();
        return result[0];
    }

}
