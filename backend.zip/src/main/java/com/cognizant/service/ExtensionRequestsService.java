package com.cognizant.service;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.IdNotValidException;

import java.util.List;

/**
 * @Author Tanmay Sharma
 * This service interface cover method for extension requests controller.
 */
public interface ExtensionRequestsService {

    public ExtensionRequestsDTO insertExtensionRequests(ExtensionRequestsDTO extensionRequestsDTO) throws IdNotValidException;

    public List<ExtensionRequestsDTO> fetchAllExtensionRequests();

    public ExtensionRequestsDTO fetchExtensionRequestsById(int id) throws IdNotFoundException;

    public List<ExtensionRequestsDTO> fetchAllExtensionRequestsByCustomerId(int customerId) throws IdNotFoundException;

    public List<ExtensionRequestsDTO> fetchAllExtensionRequestsByLoanPlanId(int loanPlanId) throws IdNotFoundException;

}
