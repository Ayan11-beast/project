package com.cognizant.service;

import com.cognizant.dto.ExtensionReasonsDTO;

import java.util.List;

/**
 * @Author Tanmay Sharma
 * This service interface cover method for extension reason controller.
 */
public interface ExtensionReasonsService {

    public List<ExtensionReasonsDTO> fetchAllExtensionReasons();
}
