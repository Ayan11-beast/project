package com.cognizant.service.impl;

import com.cognizant.dto.ExtensionReasonsDTO;
import com.cognizant.entities.ExtensionReasons;
import com.cognizant.repositories.ExtensionReasonsRepository;
import com.cognizant.service.ExtensionReasonsService;
import com.cognizant.utils.mappers.ExtensionReasonsServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;

/**
 * @Author Tanmay Sharma
 * This service cover logic for extension reason controller.
 */
@Service
public class ExtensionReasonsServiceImpl implements ExtensionReasonsService {

    private ExtensionReasonsRepository extensionReasonsRepository;

    @Autowired
    public ExtensionReasonsServiceImpl(ExtensionReasonsRepository extensionReasonsRepository) {
        this.extensionReasonsRepository = extensionReasonsRepository;
    }

    /**
     * This service method fetch all extension reasons from the database.
     *
     * @return
     */
    @Override
    public List<ExtensionReasonsDTO> fetchAllExtensionReasons() {
            Iterable<ExtensionReasons> extensionReasonsIterable = extensionReasonsRepository.findAll();
        Iterator<ExtensionReasons> extensionReasonsIterator = extensionReasonsIterable.iterator();
        return ExtensionReasonsServiceMapper.convertToExtensionReasonsDTOList(extensionReasonsIterator);
    }
}
