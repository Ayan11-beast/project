package com.cognizant.service.impl;

import com.cognizant.dto.ExtensionRequestsDTO;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.exceptions.IdNotValidException;
import com.cognizant.repositories.ExtensionRequestsRepository;
import com.cognizant.repositories.ExtensionsRequestResponsesRepository;
import com.cognizant.service.ExtensionRequestsService;
import com.cognizant.utils.mappers.ExtensionRequestsServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * @Author Tanmay Sharma
 * This service cover logic for extension requests controller.
 */
@Service
public class ExtensionRequestsServiceImpl implements ExtensionRequestsService {

    private ExtensionRequestsRepository extensionRequestsRepository;

    @Autowired
    public ExtensionRequestsServiceImpl(ExtensionRequestsRepository extensionRequestsRepository, ExtensionsRequestResponsesRepository extensionsRequestResponsesRepository) {
        this.extensionRequestsRepository = extensionRequestsRepository;
    }

    /**
     * This service method is used to add entity to corresponding table.
     *
     * @return
     * @throws IdNotValidException
     * @RequestBody extensionRequestsDTO
     */
    @Override
    public ExtensionRequestsDTO insertExtensionRequests(ExtensionRequestsDTO extensionRequestsDTO) throws IdNotValidException {
        if (extensionRequestsDTO == null) {
            throw new NullPointerException("Extension Request can not be null.");
        }
        ExtensionRequests extensionRequests = ExtensionRequestsServiceMapper.convertToExtensionRequests(extensionRequestsDTO);
        if (extensionRequests.getEmiId() <= 0) {
            throw new IdNotValidException("Unable to insert as id is not valid");
        }
        ExtensionRequests newExtensionRequests = extensionRequestsRepository.save(extensionRequests);

        return ExtensionRequestsServiceMapper.convertToExtensionRequestsDTO(newExtensionRequests);

    }

    /**
     * This service method fetch extension request of a particular id.
     *
     * @param id
     * @return
     * @throws IdNotFoundException
     */
    @Override
    public ExtensionRequestsDTO fetchExtensionRequestsById(int id) throws IdNotFoundException {
        Optional<ExtensionRequests> extensionRequestOptional = extensionRequestsRepository.findById(id);

        if (extensionRequestOptional.isPresent()) {
            ExtensionRequests extensionRequests = extensionRequestOptional.get();
            return ExtensionRequestsServiceMapper.convertToExtensionRequestsDTO(extensionRequests);
        } else {
            throw new IdNotFoundException("No data found for the id.");
        }
    }

    /**
     * This service method fetch all extension requests of a particular loan.
     *
     * @param loanPlanId
     * @return
     * @throws IdNotFoundException
     */
    @Override
    public List<ExtensionRequestsDTO> fetchAllExtensionRequestsByLoanPlanId(int loanPlanId) throws IdNotFoundException {
        Iterable<ExtensionRequests> extensionRequestsIterable = extensionRequestsRepository.findAllByLoanPlanId(loanPlanId);
        if (extensionRequestsIterable == null) {
            throw new IdNotFoundException("No data found for the loan plan id.");
        }
        Iterator<ExtensionRequests> extensionRequestsIterator = extensionRequestsIterable.iterator();
        return ExtensionRequestsServiceMapper.convertToExtensionRequestsDTOList(extensionRequestsIterator);

    }

    /**
     * This service method fetch all extension requests of a particular customer.
     *
     * @param customerId
     * @return
     * @throws IdNotFoundException
     */
    @Override
    public List<ExtensionRequestsDTO> fetchAllExtensionRequestsByCustomerId(int customerId) throws IdNotFoundException {
        Iterable<ExtensionRequests> extensionRequestsIterable = extensionRequestsRepository.findAllByCustomerId(customerId);
        if (extensionRequestsIterable == null) {
            throw new IdNotFoundException("No data found for the customer id.");
        }
        Iterator<ExtensionRequests> extensionRequestsIterator = extensionRequestsIterable.iterator();
        return ExtensionRequestsServiceMapper.convertToExtensionRequestsDTOList(extensionRequestsIterator);

    }

    /**
     * This service method fetch all extension requests present.
     *
     * @return
     */
    @Override
    public List<ExtensionRequestsDTO> fetchAllExtensionRequests() {
        Iterable<ExtensionRequests> extensionRequestsIterable = extensionRequestsRepository.findAll();
        Iterator<ExtensionRequests> extensionRequestsIterator = extensionRequestsIterable.iterator();
        return ExtensionRequestsServiceMapper.convertToExtensionRequestsDTOList(extensionRequestsIterator);

    }

}
