package com.cognizant.service.impl;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.entities.ExtensionRequests;
import com.cognizant.entities.ExtensionsRequestResponses;
import com.cognizant.entities.RequestStatus;
import com.cognizant.exceptions.IdNotFoundException;
import com.cognizant.repositories.ExtensionRequestsRepository;
import com.cognizant.repositories.ExtensionsRequestResponsesRepository;
import com.cognizant.service.ExtensionsRequestResponsesService;
import com.cognizant.utils.mappers.ExtensionsRequestResponsesServiceMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @Author Tanmay Sharma
 * This service cover logic for extension request's response controller.
 */
@Service
public class ExtensionsRequestResponsesServiceImpl implements ExtensionsRequestResponsesService {

    private ExtensionsRequestResponsesRepository extensionsRequestResponsesRepository;
    private ExtensionRequestsRepository extensionRequestsRepository;

    @Autowired
    public ExtensionsRequestResponsesServiceImpl(ExtensionsRequestResponsesRepository extensionsRequestResponsesRepository, ExtensionRequestsRepository extensionRequestsRepository) {
        this.extensionsRequestResponsesRepository = extensionsRequestResponsesRepository;
        this.extensionRequestsRepository = extensionRequestsRepository;
    }

    /**
     * This service method update extension request's response and request status of that extension request.
     *
     * @param id
     * @param extensionsRequestResponsesDTO
     * @return
     * @throws IdNotFoundException
     */
    @Override
    public ExtensionsRequestResponsesDTO extensionsRequestsApproval(int id, ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO) throws IdNotFoundException {

        ExtensionsRequestResponses extensionsRequestResponses = ExtensionsRequestResponsesServiceMapper.convertToExtensionsRequestResponses(extensionsRequestResponsesDTO);
        Optional<ExtensionRequests> extensionRequestsOptional = extensionRequestsRepository.findById(id);

        if (extensionRequestsOptional.isPresent()) {
            ExtensionRequests extensionRequests = extensionRequestsOptional.get();
            if (extensionsRequestResponsesDTO.isExtensionGranted()) {
                extensionRequests.setRequestStatus(RequestStatus.Approved);
            } else {
                extensionRequests.setRequestStatus(RequestStatus.Pending);
            }
            extensionRequestsRepository.save(extensionRequests);
            ExtensionsRequestResponses newExtensionsRequestResponses = extensionsRequestResponsesRepository.save(extensionsRequestResponses);
            return ExtensionsRequestResponsesServiceMapper.convertToExtensionsRequestResponsesDTO(newExtensionsRequestResponses);
        } else {
            throw new IdNotFoundException("No data found to update on this id.");
        }
    }
}

