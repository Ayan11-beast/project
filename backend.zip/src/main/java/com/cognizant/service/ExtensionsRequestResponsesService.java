package com.cognizant.service;

import com.cognizant.dto.ExtensionsRequestResponsesDTO;
import com.cognizant.exceptions.IdNotFoundException;

/**
 * @Author Tanmay Sharma
 * This service interface cover method for extension request's response controller.
 */
public interface ExtensionsRequestResponsesService {

    public ExtensionsRequestResponsesDTO extensionsRequestsApproval(int id, ExtensionsRequestResponsesDTO extensionsRequestResponsesDTO) throws IdNotFoundException;

}
