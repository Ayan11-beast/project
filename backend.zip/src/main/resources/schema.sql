create table Extension_Reasons (
	Id Integer,
	Reason Varchar(50),
    Constraint PK_Extension_Reasons Primary Key(Id)
);

create table Extension_Requests (
	Request_Id Integer,
	EMIs_ID Integer,
	Customer_ID Integer,
	Loan_Plan_ID Integer,
	Extension_Reasons_Id  Integer,
    Other_Reason Varchar,
    Request_Raised_On Date,
    ETA_Payment_Date Date,
    Request_Status Varchar (20),
    CONSTRAINT PK_Extension_Requests Primary Key (Request_Id),
    CONSTRAINT FK_Extension_Requests_Extension_Reasons Foreign Key (Extension_Reasons_Id)
    References Extension_Reasons(Id)
);

create table Extensions_Request_Responses (
	Id Integer,
	Response Varchar(100),
	Is_Extension_Granted boolean,
	Response_Date Date,
	Extension_Request_Id Integer,
    Constraint PK_Extensions_Request_Responses Primary Key(Id),
    Constraint FK_Extension_Requests_Extensions_Request_Responses Foreign Key(Extension_Request_Id)
    References Extension_Requests(Request_Id)
);

create table User_Authentication (
	User_Name Varchar,
	Password Varchar,
	Role Varchar,
    Constraint PK_User_Authentication Primary Key(User_Name)
);