insert into Extension_Reasons(Id,Reason)
values ('1','Reason 1'), ('2','Reason 2'), ('3','Reason 3'), ('4','Reason 4'), ('5','Other');

insert into Extension_Requests
(Request_Id,EMIs_ID,Customer_ID,Loan_Plan_ID,Extension_Reasons_Id,Request_Raised_On,ETA_Payment_Date,Request_Status)
values
('100','1000','10000','100000','1','2024-03-23','2024-03-29','New'),
('101','1001','10001','100001','2','2024-03-23','2024-03-29','New'),
('102','1002','10002','100002','3','2024-03-23','2024-03-29','New'),
('103','1003','10003','100003','4','2024-03-23','2024-03-29','New');

insert into Extension_Requests
(Request_Id,EMIs_ID,Customer_ID,Loan_Plan_ID,Extension_Reasons_Id,Other_Reason,Request_Raised_On,ETA_Payment_Date,Request_Status)
values
('104','1004','10004','100004','5','Other Reason','2024-03-23','2024-03-29','New');

insert into Extensions_Request_Responses
(Id,Response,Is_Extension_Granted,Response_Date,Extension_Request_Id)
values
('200','Response-Response-Response-Response-Response-Response-Response-Response-Response','false','2024-03-29','100'),
('201','Response-Response-Response-Response-Response-Response-Response-Response-Response','false','2024-03-29','101'),
('202','Response-Response-Response-Response-Response-Response-Response-Response-Response','false','2024-03-29','102'),
('203','Response-Response-Response-Response-Response-Response-Response-Response-Response','false','2024-03-29','103'),
('204','Response-Response-Response-Response-Response-Response-Response-Response-Response','false','2024-03-29','104');

insert into User_Authentication(User_Name,Password,Role)
values ('Rahul','pass','Customer'), ('Rishi','pass','Customer'), ('Leon','pass','Manager'), ('Sabbir','pass','Manager');