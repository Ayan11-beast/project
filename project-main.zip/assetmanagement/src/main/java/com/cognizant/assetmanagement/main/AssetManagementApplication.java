package com.cognizant.assetmanagement.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages="com.cognizant.assetmanagement.*")
@EnableJpaRepositories(basePackages = "com.cognizant.assetmanagement.repositories")
@EntityScan(basePackages = "com.cognizant.assetmanagement.entities")
//@EnableDiscoveryClient(autoRegister = true)
public class AssetManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssetManagementApplication.class, args);
	}

}
