package com.cognizant.assetmanagement;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.assetmanagement.entities.AssetsRegister;
import com.cognizant.assetmanagement.entities.SupportTickets;
import com.cognizant.assetmanagement.entities.TicketResolutions;
import com.cognizant.assetmanagement.main.AssetManagementApplication;
import com.cognizant.assetmanagement.repositories.ResolutionsRepository;

@DataJpaTest
@ContextConfiguration(classes = AssetManagementApplication.class)
public class TestResolutionsRepository {
	@Autowired
	private ResolutionsRepository resolutionsRepository;
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void TestFindAllPositive() {
//		AssetsRegister assetsRegister = new AssetsRegister();
//        assetsRegister.setAssetId(1);
//        assetsRegister.setAssetType("Laptop");
//        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
//        assetsRegister.setIssuedToEmployee("John Doe");
//        assetsRegister.setMake("Dell");
//        assetsRegister.setModelNo("XPS");
		
		TicketResolutions ticketResolutions=new TicketResolutions();
		ticketResolutions.setId(10);
		ticketResolutions.setResolutionDate(LocalDate.now());
		ticketResolutions.setResolutionDescription("Resolution");
		
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
        
        entityManager.persist(supportTicket);
        
        ticketResolutions.setTicketId(supportTicket);
        
        entityManager.persist(ticketResolutions);
        
		Iterable<TicketResolutions> it=resolutionsRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindAllNegative() {
		Iterable<TicketResolutions> it=resolutionsRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	@Test
	public void TestFindByIdPositive() {
		TicketResolutions ticketResolutions=new TicketResolutions();
		ticketResolutions.setId(10);
		ticketResolutions.setResolutionDate(LocalDate.now());
		ticketResolutions.setResolutionDescription("Resolution");
		
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
        
        entityManager.persist(supportTicket);
        
        ticketResolutions.setTicketId(supportTicket);
        
        entityManager.persist(ticketResolutions);
        Optional<TicketResolutions> ticketResolutionsOptional=resolutionsRepository.findById(10);
        
		assertTrue(ticketResolutionsOptional.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<TicketResolutions> ticketResolutionsOptional=resolutionsRepository.findById(10);
		assertTrue(!ticketResolutionsOptional.isPresent());
	}
	
	@Test
	public void TestSavePositive() {
		TicketResolutions ticketResolutions=new TicketResolutions();
		ticketResolutions.setId(10);
		ticketResolutions.setResolutionDate(LocalDate.now());
		ticketResolutions.setResolutionDescription("Resolution");
		
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
        
        entityManager.persist(supportTicket);
        
        ticketResolutions.setTicketId(supportTicket);
        
        resolutionsRepository.save(ticketResolutions);
        Optional<TicketResolutions> ticketResolutionsOptional=resolutionsRepository.findById(10);
        
		assertTrue(ticketResolutionsOptional.isPresent());
	}
	
	@Test
	public void TestDeletePositive() {
		TicketResolutions ticketResolutions=new TicketResolutions();
		ticketResolutions.setId(10);
		ticketResolutions.setResolutionDate(LocalDate.now());
		ticketResolutions.setResolutionDescription("Resolution");
		
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
        
        entityManager.persist(supportTicket);
        
        ticketResolutions.setTicketId(supportTicket);
        
        entityManager.persist(ticketResolutions);
        resolutionsRepository.delete(ticketResolutions);
        
        Optional<TicketResolutions> ticketResolutionsOptional=resolutionsRepository.findById(10);
        
		assertTrue(!ticketResolutionsOptional.isPresent());
	}
}
