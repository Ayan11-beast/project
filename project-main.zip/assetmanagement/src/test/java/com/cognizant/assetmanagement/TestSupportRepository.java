package com.cognizant.assetmanagement;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.assetmanagement.entities.AssetsRegister;
import com.cognizant.assetmanagement.entities.SupportTickets;
import com.cognizant.assetmanagement.main.AssetManagementApplication;
import com.cognizant.assetmanagement.repositories.SupportRepository;

@DataJpaTest
@ContextConfiguration(classes = AssetManagementApplication.class)
public class TestSupportRepository {
	@Autowired
	private SupportRepository supportRepository;
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void TestFindAllPositive() {
//		AssetsRegister assetsRegister = new AssetsRegister();
//        assetsRegister.setAssetId(1);
//        assetsRegister.setAssetType("Laptop");
//        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
//        assetsRegister.setIssuedToEmployee("John Doe");
//        assetsRegister.setMake("Dell");
//        assetsRegister.setModelNo("XPS");
		
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		AssetsRegister assetsRegister = new AssetsRegister();
        assetsRegister.setAssetId(1);
        assetsRegister.setAssetType("Laptop");
        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
        assetsRegister.setIssuedToEmployee("John Doe");
        assetsRegister.setMake("Dell");
        assetsRegister.setModelNo("XPS");
        
        entityManager.persist(assetsRegister);
        
        supportTicket.setAssetId(assetsRegister);
        
        entityManager.persist(supportTicket);
		Iterable<SupportTickets> it=supportRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindAllNegative() {
		Iterable<SupportTickets> it=supportRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	@Test
	public void TestFindByIdPositive() {
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		AssetsRegister assetsRegister = new AssetsRegister();
        assetsRegister.setAssetId(1);
        assetsRegister.setAssetType("Laptop");
        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
        assetsRegister.setIssuedToEmployee("John Doe");
        assetsRegister.setMake("Dell");
        assetsRegister.setModelNo("XPS");
        
        entityManager.persist(assetsRegister);
        
        supportTicket.setAssetId(assetsRegister);
        
        entityManager.persist(supportTicket);
        Optional<SupportTickets> supportTicketOptional=supportRepository.findById(20);
        
		assertTrue(supportTicketOptional.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<SupportTickets> supportTicketOptional=supportRepository.findById(20);
		assertTrue(!supportTicketOptional.isPresent());
	}
	
	@Test
	public void TestSavePositive() {
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		AssetsRegister assetsRegister = new AssetsRegister();
        assetsRegister.setAssetId(1);
        assetsRegister.setAssetType("Laptop");
        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
        assetsRegister.setIssuedToEmployee("John Doe");
        assetsRegister.setMake("Dell");
        assetsRegister.setModelNo("XPS");
        
        entityManager.persist(assetsRegister);
        
        supportTicket.setAssetId(assetsRegister);
        
//        entityManager.persist(assetsRegister);
        supportRepository.save(supportTicket);
        Optional<SupportTickets> supportTicketOptional=supportRepository.findById(20);
		assertTrue(supportTicketOptional.isPresent());
	}
	
	@Test
	public void TestDeletePositive() {
		SupportTickets supportTicket=new SupportTickets();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		AssetsRegister assetsRegister = new AssetsRegister();
        assetsRegister.setAssetId(1);
        assetsRegister.setAssetType("Laptop");
        assetsRegister.setIssuedOn(LocalDate.parse("2024-03-20"));
        assetsRegister.setIssuedToEmployee("John Doe");
        assetsRegister.setMake("Dell");
        assetsRegister.setModelNo("XPS");
        
        entityManager.persist(assetsRegister);
        
        supportTicket.setAssetId(assetsRegister);
        entityManager.persist(supportTicket);
        supportRepository.delete(supportTicket);
        Optional<SupportTickets> supportTicketOptional=supportRepository.findById(20);
		assertTrue(!supportTicketOptional.isPresent());
	}
}
