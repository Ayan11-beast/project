package com.cognizant.assetmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
//import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import com.cognizant.assetmanagement.controller.AssetManagementController;
import com.cognizant.assetmanagement.entities.SupportTickets;
import com.cognizant.assetmanagement.models.SupportTicketDTO;
import com.cognizant.assetmanagement.models.SupportTicketDetailsDTO;
import com.cognizant.assetmanagement.services.AssetManagementServices;

public class TestAssetManagementController {
	@Mock
	private AssetManagementServices assetMsanagementService;
	
	
	@InjectMocks
	private AssetManagementController assetManagementController;
	
//	@Autowired
//	private LocalValidatorFactoryBean validator;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);		
	}
	
	@Test
	public void testGetAllClientsPositiveAssertReturnValue() {
		List<SupportTicketDTO> STDTOList=new ArrayList<>();
		SupportTicketDTO supportTicket=new SupportTicketDTO();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		try {
			when(assetMsanagementService.getSupportTickets()).thenReturn(STDTOList);
			ResponseEntity<?> responseEntity=assetManagementController.getAllSupportTickets();
			List<SupportTicketDTO> actualSTDTOList=(List<SupportTicketDTO>)responseEntity.getBody();
			assertTrue(actualSTDTOList.size()>0);
		}catch(Exception e) {
			assertTrue(true);
		}
		
	}
	
	@Test
	public void testGetAllClientsPositiveAssertStatusCode() {
		List<SupportTicketDTO> STDTOList=new ArrayList<>();
		SupportTicketDTO supportTicket=new SupportTicketDTO();
		supportTicket.setTicketId(20);
		supportTicket.setTicketRaisedOn(LocalDate.now());
		supportTicket.setTicketRaisedByEmployee("Emp1");
		supportTicket.setAssignedToEmployee("Emp2");
		supportTicket.setExpectedResolution(LocalDate.of(2024, 5, 1));
		supportTicket.setTicketStatus("New");
		
		try {
			when(assetMsanagementService.getSupportTickets()).thenReturn(STDTOList);
			ResponseEntity<?> responseEntity=assetManagementController.getAllSupportTickets();
			assertEquals(404,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllClientsNegativeAssertReturnValue() {
		List<SupportTicketDTO> STDTOList=new ArrayList<>();
		try {
			when(assetMsanagementService.getSupportTickets()).thenReturn(STDTOList);
			ResponseEntity<?> responseEntity=assetManagementController.getAllSupportTickets();
			assertNull(responseEntity.getBody());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
	
	@Test
	public void testGetAllClientsNegativeStatusCode() {
		List<SupportTicketDTO> STDTOList=new ArrayList<>();
		try {
			when(assetMsanagementService.getSupportTickets()).thenReturn(STDTOList);
			ResponseEntity<?> responseEntity=assetManagementController.getAllSupportTickets();
			assertEquals(404,responseEntity.getStatusCodeValue());
		}catch(Exception e) {
			assertTrue(false);
		}
		
	}
}
