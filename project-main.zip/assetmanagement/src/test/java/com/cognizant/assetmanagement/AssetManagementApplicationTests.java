package com.cognizant.assetmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.assetmanagement.main.AssetManagementApplication;

@SpringBootTest(classes=AssetManagementApplication.class)
public class AssetManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
