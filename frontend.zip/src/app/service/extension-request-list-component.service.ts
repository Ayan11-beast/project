import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { ExtensionRequests } from "../model/extension-requests.model";

@Injectable({ providedIn: 'root' })
export class ExtensionRequestListComponentService {
  constructor(private http: HttpClient, private router: Router) { }

  extensionRequestsArrayService: ExtensionRequests[] = [];
  getExtensionRequestsUrl: string = "http://localhost:8085/api/emiextensions";

  respondToRequestService(requestId: string) {
    this.router.navigate(['/api', 'emiextensions', requestId]);
  }

  fetchAllExtensionRequestsService() {
    return this.http.get<ExtensionRequests[]>(this.getExtensionRequestsUrl);
  }
}