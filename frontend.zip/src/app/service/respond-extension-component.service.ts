import { DatePipe } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ExtensionRequestResponses } from "../model/extension-request-responses.model";
import { ExtensionRequests } from "../model/extension-requests.model";

@Injectable({ providedIn: 'root' })
export class RespondExtensionComponentService {
  constructor(private http: HttpClient, private route: ActivatedRoute,
    private router: Router, private datePipe: DatePipe) { }

  param: number;
  extensionRequest: ExtensionRequests;
  extensionRequestResponses: ExtensionRequestResponses;
  date = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

  extensionRequestsUrl: string = "http://localhost:8085/api/emiextensions/";

  fetchExtensionRequestService() {
    return this.http.get<ExtensionRequests>(this.extensionRequestsUrl + this.param);
  }

  requestRejectedService(response: string) {
    this.extensionRequestResponses = { id: this.param, response: response, extensionGranted: false, responseDate: this.date, extensionRequests: this.extensionRequest }
    return this.http.put(this.extensionRequestsUrl + this.param, this.extensionRequestResponses, { responseType: 'text' });
  }

  requestAcceptedService(response: string) {
    this.extensionRequestResponses = { id: this.param, response: response, extensionGranted: true, responseDate: this.date, extensionRequests: this.extensionRequest }
    return this.http.put(this.extensionRequestsUrl + this.param, this.extensionRequestResponses, { responseType: 'text' });
  }
}