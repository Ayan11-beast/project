import { HttpClient } from "@angular/common/http";
import { ExtensionReasons } from "../model/extension-reasons.model";
import { ExtensionRequests } from "../model/extension-requests.model";
import { Injectable } from "@angular/core";

@Injectable({ providedIn: 'root' })
export class NewExtensionRequestFormComponentService {
  constructor(private http: HttpClient) { }

  getExtensionReasonsUrl: string = "http://localhost:8085/api/emiextensions/reasons";
  postExtensionRequestUrl: string = "http://localhost:8085/api/emiextensions/newrequest";

  fetchReasonsService() {
    return this.http.get<ExtensionReasons[]>(this.getExtensionReasonsUrl)
  }

  postDataService(extensionRequest: ExtensionRequests) {
    return this.http.post(this.postExtensionRequestUrl, extensionRequest, { responseType: 'text' });
  }
}
