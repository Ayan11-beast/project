export interface ExtensionReasons {
    id: number;
    reason: string;
}