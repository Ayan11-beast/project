import { ExtensionRequests } from "./extension-requests.model";

export interface ExtensionRequestResponses {
    id: number;
    response: string;
    extensionGranted: boolean;
    responseDate: string;
    extensionRequests: ExtensionRequests;
}