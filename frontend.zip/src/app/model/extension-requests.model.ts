import { ExtensionReasons } from "./extension-reasons.model";

export interface ExtensionRequests {
    requestId: number;
    emiId: number;
    customerId: number;
    loanPlanId: number;
    otherReason: string;
    etaPaymentDate: Date;
    requestRaisedOn: Date;
    RequestStatus: string;
    extensionsReasons: ExtensionReasons;
    extensionReasonsSelect: string;
}