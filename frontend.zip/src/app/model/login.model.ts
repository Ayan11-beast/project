export class Login {
    userName: string;
    password: string;
    role: string;
}