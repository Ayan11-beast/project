import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { AppRoutingModule } from './app-routes.module';
import { AppComponent } from './app.component';
import { ExtensionRequestListComponentComponent } from './component/extension-request-list-component/extension-request-list-component.component';
import { HeaderComponent } from './component/header/header.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { NewExtensionRequestFormComponentComponent } from './component/new-extension-request-form-component/new-extension-request-form-component.component';
import { RespondExtensionComponentComponent } from './component/respond-extension-component/respond-extension-component.component';

@NgModule({
  declarations: [
    AppComponent,
    ExtensionRequestListComponentComponent,
    RespondExtensionComponentComponent,
    NewExtensionRequestFormComponentComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [
    provideAnimationsAsync(),
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
