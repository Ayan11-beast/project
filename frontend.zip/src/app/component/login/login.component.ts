import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceComponent } from '../auth-service/auth-service.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  postResponse: string;
  postErrorResponse: string;

  constructor(private authenticationService: AuthServiceComponent,
    private router: Router) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      'userName': new FormControl(null, Validators.required),
      'password': new FormControl(null, Validators.required)
    });
  }

  login() {

    this.authenticationService.authenticate(this.loginForm.value)
      .subscribe({
        next: (response) => {
          this.postErrorResponse = null;
          console.log(response);
          this.validate(response);
          this.router.navigate(['/home']);
        },
        error: (error) => {
          console.log(error);
          this.postErrorResponse = "Wrong credentials enetered";
        }
      });
  }

  validate(response) {
    if (response.userName == this.loginForm.value.userName
      && response.password == this.loginForm.value.password) {
      sessionStorage.setItem('userName', response.userName);
      sessionStorage.setItem('password', response.password);
      sessionStorage.setItem('role', response.role);
      this.router.navigate(['/home']);
    }
  }

  validateField(field: string, error: string) {
    return (this.loginForm.get(field).hasError(error)
      && (this.loginForm.get(field).touched || this.loginForm.get(field).dirty));
  }

}
