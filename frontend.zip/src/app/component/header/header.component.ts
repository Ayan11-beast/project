import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceComponent } from '../auth-service/auth-service.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  constructor(private authService: AuthServiceComponent,
    private router: Router) { }

  loginStatus() {
    return this.authService.isUserLoggedIn();
  }

  role() {
    return sessionStorage.getItem('role');
  }

  logout() {
    this.authService.logOut();
    this.router.navigate(['/login']);
  }

  login() {
    this.router.navigate(['/login']);
  }
  
}
