import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { ExtensionReasons } from '../../model/extension-reasons.model';
import { NewExtensionRequestFormComponentService } from '../../service/new-extension-request-form-component.service';

@Component({
  selector: 'app-new-extension-request-form-component',
  templateUrl: './new-extension-request-form-component.component.html',
  styleUrl: './new-extension-request-form-component.component.css'
})
export class NewExtensionRequestFormComponentComponent implements OnInit {

  constructor(private newExtensionRequestFormComponentService: NewExtensionRequestFormComponentService) { }

  extensionReasonsArray: ExtensionReasons[] = [];
  extensionReasonsStringArray: string[] = [];
  emiExtensionRequestForm: FormGroup;
  postResponse: string;
  postErrorResponse: string;
  nextDate = this.getNextDay();


  ngOnInit(): void {

    this.createForm();
    this.newExtensionRequestFormComponentService.fetchReasonsService().subscribe(
      response => {
        console.log(response);
        response.forEach((extensionReason, index) => {
          this.extensionReasonsStringArray[index] = extensionReason.reason;
        })
        this.extensionReasonsArray = response;
      }
    );
  }

  getNextDay(): string {
    const today = new Date();
    const nextDay = new Date(today);
    nextDay.setDate(today.getDate() + 1);

    return nextDay.toISOString().split('T')[0];
  }

  createForm() {
    this.emiExtensionRequestForm = new FormGroup({
      'emiId': new FormControl(null, [Validators.required, this.validateIdPattern]),
      'customerId': new FormControl(null, [Validators.required, this.validateIdPattern]),
      'loanPlanId': new FormControl(null, [Validators.required, this.validateIdPattern]),
      'extensionReasonsSelect': new FormControl("", [Validators.required]),
      'otherReason': new FormControl(null),
      'etaPaymentDate': new FormControl(null, [Validators.required, this.validateFutureDate.bind(this)]),
      'requestStatus': new FormControl("New")
    });

  }

  submitExtensionRequest() {
    let index = this.extensionReasonsStringArray.indexOf(this.emiExtensionRequestForm.value.extensionReasonsSelect);
    this.emiExtensionRequestForm.value.extensionsReasons = this.extensionReasonsArray[index];

    this.newExtensionRequestFormComponentService
      .postDataService(this.emiExtensionRequestForm.value)
      .subscribe({
        next: (response) => {
          this.displayResponse(1, response);
          console.log(response);
        },
        error: (error) => {
          this.displayResponse(2, error.error);
          console.log(error);
        }
      });

  }

  validateField(field: string, error: string) {
    return (this.emiExtensionRequestForm.get(field).hasError(error)
      && (this.emiExtensionRequestForm.get(field).touched || this.emiExtensionRequestForm.get(field).dirty));
  }

  displayResponse(flag: number, response: string) {
    if (flag == 1) {
      this.postErrorResponse = null;
      this.postResponse = response;
      this.createForm();
    } else {
      this.postResponse = null;
      this.postErrorResponse = response;
    }
  }

  validateFutureDate(control: AbstractControl): { [key: string]: boolean } {
    let enteredDate = new Date(control.value);
    let currentDate = new Date();
    if (enteredDate < currentDate && (control.value != null)) {
      return { 'etaPaymentDateFuture': true };
    } else {
      return null;
    }
  }

  onValidIdKeyDown(event) {
    const invalidCharacters = ['.', 'e', 'E', '+'];
    if (invalidCharacters.includes(event.key)) {
      event.preventDefault();
    }
  }

  validateIdPattern(control: AbstractControl): { [key: string]: boolean } {
    const validRegex = new RegExp('(^[1-9][0-9]{0,7}$)');
    if (!validRegex.test(control.value) && (control.value != null)) {
      return { 'validateIdPattern': true };
    } else {
      return null;
    }
  }
}
