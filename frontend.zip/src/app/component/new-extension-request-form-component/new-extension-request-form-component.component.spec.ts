import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewExtensionRequestFormComponentComponent } from './new-extension-request-form-component.component';

describe('NewExtensionRequestFormComponentComponent', () => {
  let component: NewExtensionRequestFormComponentComponent;
  let fixture: ComponentFixture<NewExtensionRequestFormComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NewExtensionRequestFormComponentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NewExtensionRequestFormComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
