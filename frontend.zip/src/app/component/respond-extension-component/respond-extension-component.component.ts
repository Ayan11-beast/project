import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ExtensionRequests } from '../../model/extension-requests.model';
import { RespondExtensionComponentService } from '../../service/respond-extension-component.service';

@Component({
  selector: 'app-respond-extension-component',
  templateUrl: './respond-extension-component.component.html',
  styleUrl: './respond-extension-component.component.css'
})
export class RespondExtensionComponentComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private respondExtensionComponentService: RespondExtensionComponentService,
    private router: Router) { }

  extensionRequest: ExtensionRequests;
  reason: string;
  otherReason: string;
  extensionRequestsApprovalForm: FormGroup;
  postResponse: string;
  postErrorResponse: string;

  ngOnInit(): void {
    this.route.params.subscribe(
      (params: Params) => {
        this.respondExtensionComponentService.param = +params['requestId'];
      }
    );

    this.extensionRequestsApprovalForm = new FormGroup({
      'requestId': new FormControl(null),
      'emiId': new FormControl(null),
      'customerId': new FormControl(null),
      'loanPlanId': new FormControl(null),
      'extensionReason': new FormControl(null),
      'otherReason': new FormControl(null),
      'requestRaisedOn': new FormControl(null),
      'etaPaymentDate': new FormControl(null),
      'responseDate': new FormControl(null, [Validators.required, this.responseDateFuture.bind(this)]),
      'response': new FormControl(null, [Validators.required, Validators.minLength(50)])
    });

    this.respondExtensionComponentService.fetchExtensionRequestService()
      .subscribe({
        next: (response) => {
          this.extensionRequest = response;
          this.respondExtensionComponentService.extensionRequest = response;
          this.reason = response.extensionsReasons.reason;
          this.extensionRequestsApprovalForm.setValue({
            'requestId': response.requestId,
            'emiId': response.emiId,
            'customerId': response.customerId,
            'loanPlanId': response.loanPlanId,
            'extensionReason': response.extensionsReasons.reason,
            'otherReason': response.otherReason,
            'requestRaisedOn': response.requestRaisedOn,
            'etaPaymentDate': response.etaPaymentDate,
            'responseDate': null,
            'response': null
          });
          console.log(response);
          this.displayResponse(1, "Extension request successfully uploaded");
        },
        error: (error) => {
          this.displayResponse(2, error.error);
        }
      });
  }

  requestRejected() {
    this.respondExtensionComponentService.requestRejectedService(this.extensionRequestsApprovalForm.value.response)
      .subscribe({
        next: (response) => {
          console.log(response);
          this.router.navigate(['/api/emiextensions']);
        },
        error: (error) => {
          this.displayResponse(2, error.error);
        }
      });
  }

  requestAccepted() {
    this.respondExtensionComponentService.requestAcceptedService(this.extensionRequestsApprovalForm.value.response)
      .subscribe({
        next: (response) => {
          console.log(response);
          this.router.navigate(['/api/emiextensions']);
        },
        error: (error) => {
          this.displayResponse(2, error.error);
        }
      });
  }

  validateField(field: string, error: string) {
    return (this.extensionRequestsApprovalForm.get(field).hasError(error)
      && (this.extensionRequestsApprovalForm.get(field).touched || this.extensionRequestsApprovalForm.get(field).dirty));
  }

  displayResponse(flag: number, response: string) {
    if (flag == 1) {
      this.postErrorResponse = null;
      this.postResponse = response;
    } else {
      this.postResponse = null;
      this.postErrorResponse = response;
    }
  }

  responseDateFuture(control: FormControl): { [key: string]: boolean } {
    let requestRaisedDate = new Date(this.extensionRequest?.requestRaisedOn);
    let date = new Date(control.value);
    if ((requestRaisedDate > date) && (control.value != null)) {
      return { 'responseDateFutureDate': true };
    }
    return null;
  }

}

