import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RespondExtensionComponentComponent } from './respond-extension-component.component';

describe('RespondExtensionComponentComponent', () => {
  let component: RespondExtensionComponentComponent;
  let fixture: ComponentFixture<RespondExtensionComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RespondExtensionComponentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RespondExtensionComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
