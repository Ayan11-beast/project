import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { AuthServiceComponent } from "./auth-service.component";

@Injectable({ providedIn: 'root' })
export class AuthGaurdManagerService implements CanActivate {
  constructor(private router: Router,
    private authService: AuthServiceComponent) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.authService.isUserLoggedIn() && this.authService.isUserManager()) {
      return true;
    } else if (this.authService.isUserLoggedIn && !this.authService.isUserManager()) {
      alert("Not authorized");
      return false;
    }
    else {
      this.router.navigate(['/login']);
      return false;
    }

  }
}