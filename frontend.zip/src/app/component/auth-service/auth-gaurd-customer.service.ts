import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { AuthServiceComponent } from "./auth-service.component";

@Injectable({ providedIn: 'root' })
export class AuthGaurdCustomerService implements CanActivate {
  constructor(private router: Router,
    private authService: AuthServiceComponent) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.authService.isUserLoggedIn() && this.authService.isUserNotManager())
      return true;

    this.router.navigate(['/login']);
    return false;

  }

}