import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Login } from '../../model/login.model';

@Injectable({ providedIn: 'root' })
export class AuthServiceComponent {

  loginForm: FormGroup;
  user: Login;
  backendUser: Login = new Login();

  authenticateUrl: string = "http://localhost:8085/api/authenticate";

  constructor(private http: HttpClient) { }

  authenticate(newUser) {
    return this.http.post<Login>(this.authenticateUrl, newUser);
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('userName')
    let role = sessionStorage.getItem('role');
    return !(user === null && role === null);
  }
  isUserManager() {
    let role = sessionStorage.getItem('role');
    return (role === 'Manager');
  }
  isUserNotManager() {
    let role = sessionStorage.getItem('role');
    return (role === 'Customer');
  }

  logOut() {
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('password');
    sessionStorage.removeItem('role');
    sessionStorage.clear;

  }

}
