import { Component, OnInit } from '@angular/core';
import { ExtensionRequests } from '../../model/extension-requests.model';
import { ExtensionRequestListComponentService } from '../../service/extension-request-list-component.service';

@Component({
  selector: 'app-extension-request-list-component',
  templateUrl: './extension-request-list-component.component.html',
  styleUrl: './extension-request-list-component.component.css'
})
export class ExtensionRequestListComponentComponent implements OnInit {

  constructor(private extensionRequestListComponentService: ExtensionRequestListComponentService) { }

  extensionRequestsArray: ExtensionRequests[] = [];

  ngOnInit(): void {
    this.fetchAllExtensionRequests();
  }

  respondToRequest(requestId: string) {
    this.extensionRequestListComponentService.respondToRequestService(requestId);
  }

  fetchAllExtensionRequests() {
    this.extensionRequestListComponentService.fetchAllExtensionRequestsService()
      .subscribe({
        next: (response => {
          console.log(response);
          this.extensionRequestsArray = response;
        }),
        error: (error) => {
          console.log(error.error);
        }
      });
  }

}
