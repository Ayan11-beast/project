import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtensionRequestListComponentComponent } from './extension-request-list-component.component';

describe('ExtensionRequestListComponentComponent', () => {
  let component: ExtensionRequestListComponentComponent;
  let fixture: ComponentFixture<ExtensionRequestListComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExtensionRequestListComponentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ExtensionRequestListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
