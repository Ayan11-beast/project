import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGaurdCustomerService } from './component/auth-service/auth-gaurd-customer.service';
import { AuthGaurdManagerService } from './component/auth-service/auth-gaurd-manager.service';
import { ExtensionRequestListComponentComponent } from './component/extension-request-list-component/extension-request-list-component.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { NewExtensionRequestFormComponentComponent } from './component/new-extension-request-form-component/new-extension-request-form-component.component';
import { RespondExtensionComponentComponent } from './component/respond-extension-component/respond-extension-component.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'api/emiextensions', component: ExtensionRequestListComponentComponent, canActivate: [AuthGaurdManagerService] },
  { path: 'api/emiextensions/newrequest', component: NewExtensionRequestFormComponentComponent, canActivate: [AuthGaurdCustomerService] },
  { path: 'api/emiextensions/:requestId', component: RespondExtensionComponentComponent, canActivate: [AuthGaurdManagerService] },
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
